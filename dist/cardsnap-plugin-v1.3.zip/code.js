const PLUGIN_WIDTH = 420;
const PLUGIN_HEIGHT = 720;
const SETTINGS_KEY = "joybuy-card-copilot-settings-v1";
const LOCAL_BRIDGE_URL = "http://localhost:3210/proxy";
const LOCAL_PRD_EXTRACT_URL = "http://localhost:3210/extract-prd";
const LOCAL_BRIDGE_TOKEN = "joybuy-card-copilot-7f4d2b91-2026";
const DEFAULT_SETTINGS = {
  provider: "auto",
  endpoint: "",
  model: "",
  apiKey: ""
};
const DEFAULT_TRANSLATIONS = {
  zh: "满 £50 减 £5",
  en: "£5 off when you spend £50",
  de: "£5 Rabatt ab £50",
  fr: "5 £ de remise dès 50 £",
  nl: "£5 korting vanaf £50",
  it: "5 £ di sconto su una spesa di 50 £"
};
const LOCALE_LABELS = {
  zh: "ZH",
  en: "EN",
  de: "DE",
  fr: "FR",
  nl: "NL",
  it: "IT"
};
const SCENE_COPY_LIBRARY = {
  "phone case": { zh: "手机壳", de: "Handyhülle", fr: "Coque de téléphone", nl: "Telefoonhoesje", it: "Custodia per telefono" },
  "drink": { zh: "饮料", de: "Getränke", fr: "Boissons", nl: "Dranken", it: "Bevande" },
  "air fryer": { zh: "空气炸锅", de: "Heißluftfritteuse", fr: "Friteuse à air", nl: "Airfryer", it: "Friggitrice ad aria" },
  "search results": { zh: "搜索结果", de: "Suchergebnisse", fr: "Résultats de recherche", nl: "Zoekresultaten", it: "Risultati di ricerca" },
  "filter": { zh: "筛选", de: "Filter", fr: "Filtrer", nl: "Filter", it: "Filtra" },
  "sort": { zh: "排序", de: "Sortieren", fr: "Trier", nl: "Sorteren", it: "Ordina" },
  "sort by": { zh: "排序", de: "Sortieren nach", fr: "Trier par", nl: "Sorteren op", it: "Ordina per" },
  "brand": { zh: "品牌", de: "Marke", fr: "Marque", nl: "Merk", it: "Marca" },
  "category": { zh: "品类", de: "Kategorie", fr: "Catégorie", nl: "Categorie", it: "Categoria" },
  "grid": { zh: "双列", de: "Raster", fr: "Grille", nl: "Raster", it: "Griglia" },
  "tailor your experience": { zh: "定制你的体验", de: "Gestalte dein Erlebnis", fr: "Personnalisez votre expérience", nl: "Stem je ervaring af", it: "Personalizza la tua esperienza" },
  "recommendations based on your interests": { zh: "根据你的兴趣推荐", de: "Empfehlungen basierend auf deinen Interessen", fr: "Recommandations selon vos centres d’intérêt", nl: "Aanbevelingen op basis van je interesses", it: "Consigli basati sui tuoi interessi" },
  "saved collection": { zh: "已收藏合集", de: "Gespeicherte Sammlung", fr: "Collection enregistrée", nl: "Opgeslagen collectie", it: "Raccolta salvata" },
  "best seller": { zh: "畅销商品", de: "Bestseller", fr: "Meilleure vente", nl: "Bestseller", it: "Più venduto" },
  "lightning offers": { zh: "闪购优惠", de: "Blitzangebote", fr: "Offres flash", nl: "Bliksemaanbiedingen", it: "Offerte lampo" },
  "buy 1 get 1 free": { zh: "买一赠一", de: "1 kaufen, 1 gratis", fr: "1 acheté, 1 offert", nl: "1 kopen, 1 gratis", it: "Prendi 2, paghi 1" },
  "get it today": { zh: "今日送达", de: "Heute geliefert", fr: "Livré aujourd’hui", nl: "Vandaag bezorgd", it: "Consegna oggi" },
  "get it by today": { zh: "今日送达", de: "Heute geliefert", fr: "Livré aujourd’hui", nl: "Vandaag bezorgd", it: "Consegna oggi" },
  "sold by joybuy": { zh: "Joybuy 自营", de: "Verkauft von Joybuy", fr: "Vendu par Joybuy", nl: "Verkocht door Joybuy", it: "Venduto da Joybuy" },
  "install & recycle": { zh: "安装与回收", de: "Installation & Recycling", fr: "Installation et recyclage", nl: "Installatie en recycling", it: "Installazione e riciclo" },
  "install & recyle": { zh: "安装与回收", de: "Installation & Recycling", fr: "Installation et recyclage", nl: "Installatie en recycling", it: "Installazione e riciclo" },
  "home": { zh: "首页", de: "Startseite", fr: "Accueil", nl: "Home", it: "Home" },
  "categories": { zh: "分类", de: "Kategorien", fr: "Catégories", nl: "Categorieën", it: "Categorie" },
  "cart": { zh: "购物车", de: "Warenkorb", fr: "Panier", nl: "Winkelwagen", it: "Carrello" },
  "account": { zh: "我的", de: "Konto", fr: "Compte", nl: "Account", it: "Account" },
  "me": { zh: "我的", de: "Konto", fr: "Compte", nl: "Account", it: "Account" },
  "professional repair hair serum 100ml": { zh: "专业修护护发精华 100ml", de: "Professionelles Reparatur-Haarserum 100 ml", fr: "Sérum capillaire réparateur professionnel 100 ml", nl: "Professioneel herstellend haarserum 100 ml", it: "Siero professionale riparatore per capelli 100 ml" },
  "original taste 330ml × 24 cans": { zh: "经典口味汽水 330ml × 24", de: "Originalgeschmack 330 ml × 24 Dosen", fr: "Goût original 330 ml × 24 canettes", nl: "Originele smaak 330 ml × 24 blikjes", it: "Gusto originale 330 ml × 24 lattine" },
  "seeded sourdough bread system": { zh: "籽粒酸面包套装", de: "Sauerteigbrot mit Saaten", fr: "Pain au levain aux graines", nl: "Zuurdesembrood met zaden", it: "Pane a lievitazione naturale con semi" },
  "french door refrigerator freeze ice & water": { zh: "法式多门冰箱 冷冻制冰与饮水", de: "French-Door-Kühlschrank mit Eis und Wasser", fr: "Réfrigérateur multiportes avec glace et eau", nl: "French-door koelkast met ijs en water", it: "Frigorifero French door con ghiaccio e acqua" },
  "original taste 330ml × 24": { zh: "经典口味汽水 330ml × 24", de: "Originalgeschmack 330 ml × 24", fr: "Goût original 330 ml × 24", nl: "Originele smaak 330 ml × 24", it: "Gusto originale 330 ml × 24" },
  "★ 4.5 | 100k+ sold": { zh: "★ 4.5 | 已售 100k+", de: "★ 4,5 | 100k+ verkauft", fr: "★ 4,5 | 100k+ vendus", nl: "★ 4,5 | 100k+ verkocht", it: "★ 4,5 | 100k+ venduti" },
  "4.5 · 100k sold": { zh: "4.5 · 已售 100k", de: "4,5 · 100k verkauft", fr: "4,5 · 100k vendus", nl: "4,5 · 100k verkocht", it: "4,5 · 100k venduti" }
};
const DESIGN_HEADER_HEIGHT = 364;
const JOYBUY_WORDMARK_SVG = `<svg width="635" height="174" viewBox="0 0 635 174" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M183.657 160.719C169.845 168.685 153.827 173.268 136.739 173.268C119.735 173.268 103.781 168.727 90.011 160.825L104.059 136.52C113.695 142.023 124.853 145.192 136.739 145.192C148.709 145.192 159.93 142.023 169.61 136.413L183.657 160.719ZM244.671 82.578L261.31 30.626H296.794L264.801 118.341C256.428 142.026 253.794 155.474 236.769 165.925C223.856 173.848 197.579 173.227 197.579 173.227V145.023C211.349 145.023 217.603 142.304 222.335 137.828C225.676 134.659 227.903 127.035 228.931 124.102L190.619 30.626H227.218L244.671 82.578ZM582.876 82.578L599.516 30.626H635L603.006 118.341C594.633 142.026 592 155.474 574.975 165.925C562.062 173.848 535.785 173.227 535.785 173.227V145.023C549.555 145.023 555.809 142.304 560.541 137.828C563.882 134.659 566.109 127.035 567.137 124.102L528.825 30.626H565.423L582.876 82.578ZM69.541 0.02V89.019C69.541 118.378 54.358 131.655 31.766 131.655C11.5 131.655 1.029 119.898 0.992 119.857L14.184 95.614C25.319 107.392 38.125 104.266 38.125 88.762V0.062C38.232-0.045 69.541 0.02 69.541 0.02ZM460.059 89.806C460.059 98.329 466.548 102.654 473.165 102.654C479.782 102.654 488.07 96.293 488.07 86.914V30.851H520.278V128.973H491.068V120.193C491.025 120.27 484.639 131.607 464.214 131.607C441.857 131.607 427.98 115.203 427.98 91.219V30.851H460.059V89.806ZM342.454 36.533C345.196 33.856 352.777 27.968 366.739 27.968C394.963 27.989 415.264 50.453 415.264 79.534C415.264 108.615 395.434 131.572 367.081 131.572C353.633 131.572 344.981 126.561 339.563 121.315V128.939H310.011V0H342.454V36.533ZM136.767 28.155C166.683 28.155 190.968 51.241 190.968 79.744C190.968 108.247 166.705 131.332 136.767 131.332C106.829 131.332 82.566 108.247 82.566 79.744C82.566 51.241 106.829 28.155 136.767 28.155ZM136.745 56.487C124.153 56.487 113.96 66.895 113.96 79.744C113.96 92.593 124.154 103 136.745 103C149.337 103 159.53 92.593 159.531 79.744C159.531 66.594 149.337 56.487 136.745 56.487ZM361.92 57.777C350.977 57.777 341.126 65.229 341.126 79.771C341.126 94.311 350.742 101.999 361.92 101.999C373.098 101.999 383.077 93.947 383.077 79.771C383.056 65.594 373.934 57.778 361.92 57.777Z" fill="white"/></svg>`;
const LINK_ICON_SVG = `<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.25 11.75L11.75 8.25M6.15 13.85L4.9 15.1a3.18 3.18 0 104.5 4.5l2.45-2.45a3.18 3.18 0 000-4.5M13.85 6.15L15.1 4.9a3.18 3.18 0 10-4.5-4.5L8.15 2.85a3.18 3.18 0 000 4.5" stroke="#D7D7DA" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" transform="translate(0 -0.05)"/></svg>`;
const FIELD_CATALOG = [
  { slotNumber: 1, key: "rankingBadge", label: "排行榜徽章（可选）", english: "Ranking Badge", name: /ranking[\s_-]*(?:badge|tag)|rank[\s_-]*(?:badge|tag)|排行榜|排行徽章|排行标签/i, text: null },
  { slotNumber: 2, key: "productPicture", label: "商品图片", english: "Product Picture", name: /product[\s_-]*(?:picture|image)|商品图|main[\s_-]*image/i, text: null },
  { slotNumber: 3, key: "sku", label: "标准产品单位（可选）", english: "SPU", name: /(?:^|[\s_-])spu(?:$|[\s_-])|product[\s_-]*(?:unit|property|properties)|标准产品单位|产品属性/i, text: null },
  { slotNumber: 4, key: "productHighlights", label: "商品亮点（可选）", english: "Product Highlights", name: /product[\s_-]*highlights?|商品亮点|卖点/i, text: /^(?:sponsored|best before|life 3d\+|new&hot|top deal|private label|new|too good to waste|bbd:)/i },
  { slotNumber: 5, key: "brandName", label: "品牌名称（可选）", english: "Brand Name", name: /brand[\s_-]*name|品牌名称|品牌名/i, text: null },
  { slotNumber: 6, key: "title", label: "标题", english: "Title", name: /product[\s_-]*(?:title|name)|(?:^|[\s_-])title(?:$|[\s_-])|商品标题|商品名称|标题/i, text: null },
  { slotNumber: 7, key: "ratingSales", label: "评分 / 销量（可选）", english: "Rating / Sales", name: /rating(?:&sold)?|sales[\s_-]*volume|viewed|reviews?|销量|评分|浏览量/i, text: /4\.5|100k\+ sold|189 reviews|200 viewed in 48 hours|only 50 items available/i },
  { slotNumber: 8, key: "aiRecommendation", label: "AI 推荐理由（可选）", english: "AI Recommendation", name: /ai[\s_-]*(?:recommendation|reason)|recommendation[\s_-]*reason|ai 推荐理由|推荐理由/i, text: /more buying choices|more options inside|beautifully packaged|ultimate silence|bestseller#|lowest price in last 30 days|previously purchased|previously added to cart|bought from this store before|added from this store before|ai recommendation/i },
  { slotNumber: 9, key: "singlePromotion", label: "单促 / 业务类型（可选）", english: "Single Promotion", name: /single[\s_-]*promotion|individual[\s_-]*promotion|business[\s_-]*type|单促|业务类型/i, text: /price match amazon|lightning offers|everyday low price|happy hour|welcome offer|outlet|pre-sale|ends in 23:10:20|early access|coming soon|starts at aug 26, 00:00|contract/i },
  { slotNumber: 10, key: "price", label: "价格", english: "Price", name: /(?:^|[\s_-])price(?:$|[\s_-])|sale[\s_-]*price|价格/i, text: /^[£€$¥￥]\s?\d[\d,.]*$/i },
  { slotNumber: 11, key: "masterPromotion", label: "总促（可选）", english: "Master Promotion", name: /master[\s_-]*(?:pr|promotion)|total[\s_-]*(?:pr|promotion)|总促/i, text: /pay £339\.99 after promotion|buy 2 get 30% off|£15\.00 off over £100\.00|buy 1 get 1 free|3 for 2|£3\.00 in gifts|gift up to £3\.00|pick 3 gifts|3 gifts|\+500 pts = £5 off|repeat & save up to 7%|limited-time discount £5|free gift|buy £100|\bpoints?\b/i },
  { slotNumber: 12, key: "unitPrice", label: "单位价格（可选）", english: "Unit Price", name: /unit[\s_-]*price|per[\s_-]*(?:unit|kg|lb|item)|单位价格|每单位/i, text: /per\s+(?:unit|kg|lb|100\s?g|item)|\/\s*(?:kg|lb|unit|100\s?g)/i },
  { slotNumber: 13, key: "bottleDeposit", label: "瓶押金（可选）", english: "Bottle Deposit", name: /bottle[\s_-]*deposit|deposit|瓶押金|押金/i, text: /(?:excl\.?|incl\.?)\s*deposit|deposit\s*[£€$¥￥]|瓶押金|押金/i },
  { slotNumber: 14, key: "stock", label: "少库存（可选）", english: "Stock", name: /(?:low[\s_-]*)?stock|inventory|少库存|库存/i, text: /only\s+\d+\s+left|out of stock|仅剩|售罄|库存/i },
  { slotNumber: 15, key: "fulfillment", label: "履约时效（可选）", english: "Fulfillment Time", name: /fulfillment|delivery[\s_-]*(?:time|promise)|履约时效|履约|配送时效/i, text: /get it by today/i },
  { slotNumber: 16, key: "officialTag", label: "自营标签（可选）", english: "Official Tag", name: /official[\s_-]*(?:self[\s_-]*operated)?[\s_-]*tag|seller[\s_-]*tag|自营标签|自营/i, text: /sold by joybuy/i },
  { slotNumber: 17, key: "service", label: "服务（可选）", english: "Service", name: /(?:^|[^a-z])service(?:$|[^a-z])|service[\s_-]*tag|in(?:s|a)tall[\s_&-]*rec(?:y|)cle|服务|服务条例/i, text: /install & recyle|gift wrapping/i },
  { slotNumber: 18, key: "performance", label: "性能（可选）", english: "Performance", name: /performance|性能|product[\s_-]*sheet/i, text: /product\s*sheet|energy|性能|能效/i },
  { slotNumber: 19, key: "actionButton", label: "按钮（加购或查看详情）", english: "Button", name: /add[\s_-]*(?:button|cart)|detail[\s_-]*button|action[\s_-]*button|notify[\s_-]*button|reservation[\s_-]*button|加购|查看详情|按钮/i, text: /add to cart|view detail|notify|加购|查看详情/i }
];
const FIELD_COMPONENT_CONTROLS = {
  rankingBadge: {
    properties: [/^show ranking (?:badge|tag)$/, /^show number tag$/],
    layers: [/ranking (?:badge|tag)/, /number tag/]
  },
  productPicture: {
    properties: [/^show product (?:picture|image)$/],
    layers: [/product (?:picture|image)/, /^main image$/]
  },
  sku: {
    properties: [/^show spu (?:color|text)$/, /^show product propert(?:y|ies)$/],
    layers: [/^spu (?:color|text)$/, /product propert(?:y|ies)/, /^component 71$/, /^color$/]
  },
  productHighlights: {
    properties: [/^show product highlights?$/],
    layers: [/product highlights?/]
  },
  brandName: {
    properties: [/^show brand(?: name)?$/],
    layers: [/brand default/, /brand name/]
  },
  title: {
    properties: [/^show (?:product )?title$/],
    layers: [/^title$/]
  },
  ratingSales: {
    properties: [/^show rating(?: and sold| sales)?$/],
    layers: [/rating and sold/, /rating sales/]
  },
  aiRecommendation: {
    properties: [/^show ai recommendation(?: reasons)?$/],
    layers: [/ai recommendation(?: reasons)?/]
  },
  singlePromotion: {
    properties: [/^show individual promotion$/, /^show single promotion$/],
    layers: [/individual promotion/, /single promotion/]
  },
  price: {
    properties: [/^show price$/],
    layers: [/^price$/, /price first line/, /price second line/]
  },
  unitPrice: {
    properties: [],
    layers: [/unit price/, /price unit/]
  },
  masterPromotion: {
    properties: [/^show (?:total|master) promotion$/],
    layers: [/(?:total|master) promotion/]
  },
  bottleDeposit: {
    properties: [/^show bottle deposit$/],
    layers: [/bottle deposit/]
  },
  stock: {
    properties: [/^show stock$/],
    layers: [/^stock$/]
  },
  fulfillment: {
    properties: [/^show fulfillment(?: time)?$/, /^show guarantee(?:d)?(?: delivery)?$/, /^show yunsong$/],
    layers: [/fulfillment time/, /guarantee(?:d)?(?: delivery)?/, /yunsong/]
  },
  officialTag: {
    properties: [/^show tag fulfillment$/, /^show official(?: tag)?$/, /^show sold by joybuy$/],
    layers: [/tag fulfillment/, /sold by joybuy/, /official tag/]
  },
  service: {
    properties: [/^show install (?:and )?recycle$/, /^show service$/],
    layers: [/install (?:and )?recycle/, /^service$/]
  },
  performance: {
    properties: [/^show energy$/, /^show performance$/],
    layers: [/^energy$/, /^performance$/]
  },
  actionButton: {
    properties: [/^show add to cart$/, /^show notify button$/, /^show (?:action )?button$/],
    layers: [/btn cart/, /notify button/, /add button/, /add to cart/, /view detail/]
  }
};
const EXCLUSIVE_FIELD_CONTROL_PREFERENCES = {
  actionButton: [
    /^show add to cart$/,
    /^show (?:action )?button$/,
    /^show notify button$/
  ]
};
const PROTECTED_NON_CATALOG_FIELD_CONTAINERS = [
  /^(?:show )?(?:country of origin|country origin|origin country|made in)(?: (?:tag|label|default|optional|text|value|long text|variant \d+))*$/,
  /^(?:显示 )?(?:原产国|原产地|产地)(?: 标签| 文案| 默认| 可选| 长文案| 变体 \d+)*$/,
  /(?:^| )(?:favorite button|tag like|wishlist button|收藏按钮)(?: |$)/,
  /(?:^| )(?:dietary badges?|dietary preferences?|food preference badges?|饮食习惯标签|饮食标签)(?: |$)/,
  /(?:^| )(?:frozen product label|frozen label|冻品标签)(?: |$)/,
  /(?:^| )(?:membership identification|membership badge|member badge|会员标识)(?: |$)/,
  /(?:^| )(?:sequential label|sequence label|order label|顺序标签)(?: |$)/,
  /(?:^| )(?:quantity selector|stepper|数量选择器)(?: |$)/,
  /(?:^| )(?:reservation components?|booking controls?|预约组件)(?: |$)/,
  /(?:^| )(?:countdown|count down|倒计时)(?: |$)/
];
const DEMO_PRODUCT_IMAGES = [
  "/9j/4AAQSkZJRgABAQAASABIAAD/4QCSRXhpZgAATU0AKgAAAAgABQEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAAExAAIAAAAGAAAAWodpAAQAAAABAAAAYAAAAAAAAABIAAAAAQAAAEgAAAABRmlnbWEAAAOgAQADAAAAAQABAACgAgAEAAAAAQAAAHCgAwAEAAAAAQAAAHAAAAAA/8AAEQgAcABwAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/bAEMAAwMDAwMDBQMDBQcFBQUHCQcHBwcJDAkJCQkJDA4MDAwMDAwODg4ODg4ODhERERERERQUFBQUFhYWFhYWFhYWFv/bAEMBAwQEBgUGCgUFChcQDRAXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXF//dAAQAB//aAAwDAQACEQMRAD8A/VKiiigAooooAKKKjmmit4nnndY441LMzHCqo5JJPAAoA+IP2kPHvi/QPBnivUdD1K4sp7C9hht5YHZDGuI8gYOOSx6ivMf2Uvil8QvFHiDSLfxFrl3qEV19oEouJDIG2l9vXOMYHTFUPi54k8OeK9d8VaTp97cX8V7cW8lgp2m1Dp/x8M5YZKnAEYwRxnpiuZ+Bl1ofgr4j6O2u3B0+2VpN7xlUhDMDs3EDhd33ug554zWPtFex9YuHMQ6Lrt7K9rO+1/v6ep+s1FMjkjmjWaFg6OAyspyCDyCCOoNPrY+TCiiigAooooA//9D9UqKKKACiiigCrfX1rp1rJe3sgiiiG5mPavkj4oeMLrxxCdJgE0GmKclI3ZGlPq5Ujgdl6V678ULmaaa201TiLBdh6t/+qvJ7nTwiEKMe+K55y6H1+VYaFNRxEtZdPL/gnzJN4Q0uwkaa2iZH6Al2Y4/HNcNrOlws+6QElffB/SvojW7QKXwOvNeSatZh5CMcVzM/QKNaUlqz0v4LfHG58C7fDusGS70fd8u4lpLfPdM5+X1Xp3HfP6EaVqun63YRappUyXFtOu5JEOQR/iO47V+TdppYWUFBjmvsb9nzWLuy1W58JMS1rLbG8jB/gdHVGA9mDZ/Ct6c3flZ8lnuWU3CWKpaSW/n/AME+rqKKK6j89CiiigD/0f1SooooAKKKKAPHviCgbVISf7n+FcTdxAofeu68ff8AIUh/3P8ACvP9avI9NsnvJRlEZAxzgKruqliTxhc5PsK5Zbs+ywkrUYX7Hl/iCMBm+leR6mg8w49a6/xH4vCE+VDFOSZcpDOGZBGxALZAGJANyY6jrXlmo+KIfkZ4h87PkLIrbAp2qWxx8xBx6CsmmfVYfE07Wubtqo8wV9JfBMAfEBf+wVL/AOjYq+b7NkkZXiYOp6MvII9Qa+k/gp/yP6/9gqb/ANGxU6fxIjNf91qeh9d0UUV3H5MFFFFAH//S/VKiiigAooooA8j8ejOqwD1X/CsPXPhzqGvadPpWoWqT28+A6edsJ2sGXDIysCGAIIINbvjz/kLW/wBB/MVU1j4deJn1bVNb8Pay9pPqUm4pvaOMKEREJ2KSWQgtznP3OFY4ySu2e9PEyo0aXLbVPc8H1X9m+6cN/ZemLCT1b7Y7Z6Egh5SOwOevFcLcfs4eJbQDbZJkE/N9t28NnPAkx3Ir6eX4d/ESPVZz/wAJM8enTTTTMsLyRy7JXL+WowVTDHf5ituOfLwFGa4t/CvxkuJZ01DxC9qsLIvml1f7S4aQvOiCNhGmwogi4BwWyCBT5F3MI5k4/wDLqH/gP/BPGbL4UeJtLjjtI7eCKOL5VUTqcD8ya98+EvhPWNM8W/2tdCIQJYvbna+5t7urDjHTCnmtR4pLeCG3lcyvHGiNIxyzsqgFiTySx5ruvA/+vm+i/wDs1JU0nc3r51XrU3RklZq2i/4J6VRRRWp4IUUUUAf/0/1SooooAKKKKAPJPHn/ACFrf6D+Yr0abVo4ZjCYLhiCRlYmYYHcEdRXnPjw/wDE2tv90fzFX9VbXPt115N9dxRrL8ioUAA4PG62Y7Tg/wAR+tZx3Z6eK/g0fRnUnX7d4XkW2vMKwXAt3JOe4AHSuY1HW7aZMiC6TJIw9u6njHXPTr9evGBXPXl1rsEMkraxfLGQrBv3I2kHlRm1I54HOc7uMYp76T4jdC99ql7GrKWBY2rsMgYGFhGMf5zWh5hlX3EpHoa7PwOP3030X/2avP8A7LNaF45rqW7LNnfMEDD2Hlqox+Feg+Bv9dP9F/rQB6TRRRQAUUUUAf/U/VKiiigAooooA8i8e4/ta2/3f6irms2WqyarNJFJqMULPjMVxIEHTlVCMBn8vpVLx8f+Jtbn0X/CpL3xLpbXElyNUvoldwwjVMqoHVeucH8KyTSbuezWozqUaXs430YWmheJLiMyfbL5IyxjYSXjK+DgMyhoByvVTkZx70at4YIUk6vqjHnrcjofYJjiudu/Hfh+Cd5pdb1FVJJCLD8oySfXPAOBz2/Csib4v+A7a1FrLe3s7gkmSW3Ysx9znH5cVXPHucyy/Evak/uZq3n+tNdr4G/10/0X+tfPtx8SfC8znZqF0ec/8eij8K9T+F3jDR9T1iTRbWSeW5e3NyGkiCL5aMFPIPXLDHHrTUk9mKeAxFOLnOm0l5HvFFFFUcAUUUUAf//V/VKiiigAooooA8e+IB/4mkWP7h/pXm163yfhXq/jzSNVubqO8srd7iMKQfL5YHjt1rye+s9b2YTSr5uO0Dn+lck0+Y+2wE4+yguZfeeZa2eDXlWpH96SfWvXdX0TxVMCIdE1A5/6dpP8K83v/CHjqZj5egakc/8ATrJ/hWTi+x9bRr0orWa+9HORt82K+ivgM+74iAf9Qib/ANHRV4Gngb4iA/u/D2qf+Azj+Yr6S+AXgjxxpHimbXfEmmy2Fqti9uhnKiR3eRGGEBJwApyTirpxfMnY4c2xNGWFqKM1e3dH13RRRXaflQUUUUAf/9k=",
  "/9j/4AAQSkZJRgABAQAASABIAAD/4QCSRXhpZgAATU0AKgAAAAgABQEaAAUAAAABAAAASgEbAAUAAAABAAAAUgEoAAMAAAABAAIAAAExAAIAAAAGAAAAWodpAAQAAAABAAAAYAAAAAAAAABIAAAAAQAAAEgAAAABRmlnbWEAAAOgAQADAAAAAQABAACgAgAEAAAAAQAAAHCgAwAEAAAAAQAAAHAAAAAA/8AAEQgAcABwAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/bAEMAAwMDAwMDBQMDBQcFBQUHCQcHBwcJDAkJCQkJDA4MDAwMDAwODg4ODg4ODhERERERERQUFBQUFhYWFhYWFhYWFv/bAEMBAwQEBgUGCgUFChcQDRAXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXF//dAAQAB//aAAwDAQACEQMRAD8A/VKiiigAoorgPib4+034a+D7zxRqBDNENlvFnBmnfhEH48n0UE0pNRV2a0aU6040qau27I8/1X4s+I4dUurGLSDaW1uzL9qkzKp2Eg/6vI5x069q+T/iJ+1R4y064aDQ9SMRGfu2eFGPeWMZrwK18ceKLSS7vre+nhuL6VppZIpWTMjksxABwCST2rpLT42fEuxP7rW5pABjbPHFOuPpKjV46zKN9Ys/UKvh/iEr068X6pr8kzSH7Tvxce2im/4SeEvMNwXFuhUejB41wfpn61btP2o/ivFGss+ueaA21gsUMhHcY2IQQfXPHfFc/qHxs8Y6hbtb30emTbush021D/8AfSxrXm2peLr66fdJHbof+mVvEn54XmtFmFN9H/XzPJnwXjYbzh97/wDkT7S8BftM+KNTuI7XWLr/AFnCvcWwRC393cijn9K+gfDXxh1zVfEVrodzo4eC4dU+1xvsUFu4D43euBzXwt+zxrdprOs6zperwpcTLZiaz3gAIysVYgDGT8y+uK8s0vxxr1nqeleKftMtze6XcJOhmkZstG2SDk9DyD7Gt3ilZSS3POocO1KlapQc1eNtru91p27WP29ormvB3irS/G3hmw8UaO262vohIAeqN0ZG91YEH6V0tdqd9UfKTg4ScJKzQUUUUyD/0P1SooooAK+D/wBrrT9W8QeJvD+h2bMYo7WWYR5AUyO+3oSMsQoCjqeg6194V86fFC0R/HUd8bWK5eLRCqCa2+2KPMvYUb91kE5VjkjlRk+1cuJg503FPc+k4fxccJjFipxuoqTt8mfl9e6Zc2czW7HLJweo/Q16X4Z+H1/qvhrUIZ2geW70qTWtPRGJnRrJ2VwQVAKyoJFYKzbWCbgpwDJ8WIxafEHWtLTmKwupLaInlvLViV3HqxAbAJ7ADtXonwkm1iLwveajqUhsNEs7lra31YgMtjc3iBJEkQ48y0mygmAOUcq4xyw+Vp/xHBn9FZo5fUKeMpPlb5Xa/fZLvrbRatXSvs/m3wz4V13xprMWg+H4llvbmOR4Y3YIJPLQuVDHjcQDjPBPcVnaj4J8YWF5dadf6bPb3toN8tpKu248sZJkSM8yRrj5mTIHU8c19PWvh/U/AXjOKTxLpAN5JBNFLDZ/LBq1lLGVeewlTAS6Rf3hjG3fjKhWyretQz6zfWWnXF/CfiL4PMqvYaxaca3pr54MgUrIzR/xFQGI6/3T00qd1aW/9fM+TzDHOM1Ok06bS67vXZ/C9Nk2m9bXacV8DfDbXr7wZ440zxD5ZaGOXypgOhhm+R/yyGHuBW/4y8Jy+HPiDrnhgt5MMF0zxbuf3UoEqDj0VwPwrqfjRpelaf4616LRrSXT0W7wttKFXBeIOzoq5xG7ksnONpHA6VB8SdQGsfEWfVgci+stOuMjv5llCf51opuzg+j/AMzCGGiqsMVTbtODbv5OLX/pTPrn9ii+vTpfibR3naW1tbi3eJD91WkVw5Hpu2rke1fcdfBv7EnTxdx/y1s+fwlr7yr3sP8Aw0fk3EC/4UKvy/JBRRRXSfOn/9H9UqKKKACvj39ou9ii8Y6HYyIJDc2khRNwj3NHKD8rF4wGGdy/MORkHOAfsKvgP9sXB8TeHlIyPsk3/oxa4Mc7UW/T8z7Xg6kq2a0qbdrqX/pLPnT4h6kmoa2QxWW5Uu93ONpMk8hy2WXIbaoUEgkbs4JHJ6Xxp4hkj+FPgzwlpiPHYGCa/vZFUhJr155I9rN0JjKtx7j0FeT3Z/eH2xXutvqF3d/DDRdRsL9rSHTDJpk5YeZawTl2dFvIsMGt7xHX52UhJFOQQxx8rTbk5+a/VH9DZlTjhY4VKN1GXyvyySez6vT8NbGR8Mvib4k08R+CL3TT4p0WU7106XmW38sbvMtpSf3RjA3ckKMZBU817ZB4d0u38Rp40+GniUeEbzUpCbjRNaQxQ3LRBPN+XdiTdvViybuWyrDoPm4SHwh4n0vWLCwguTeRSJc6RHILqORJN0MsSNG0hMU6EtHyWXOOQoJ9pu/h+vizT7S2+FP2a60WBR9s8J6qz293bu5zJIzSlnEhP3JgVwAApZcg99Bya5Hq19/y6/1sfCZ1Ciqqr037OM07uycXvdSTvG90rOyT19/Y8U+OE7r441ezn1VdXlNzDMJ02kJH5ICwlkwuYs7cAdsnkkV5re3YuL7S5zz/AMS2CE/9sC8I/wDHUFb/AMTfA0nw78X3nhV5BLHCsc0D8bjDMu5A2ABuXlTgDJGQMEVxySGQWDY4VJo8/wC7IT/7NUK/tJXOykofV6TpyuuVWdrXVu3T0Pu39iNkZPF397zrQ/hiXH9a+8q+A/2IH/feLU/2rQ/+ja+/K+lofw0finEH+/1Pl+SCiiiug+eP/9L9UqKKKACvgT9sT/kZvDx/6dJv/QxX33XwL+2N/wAjF4dP/TrP/wChrXn4/wDgS+X5n3XBH/I5of8Ab3/pLPjy55ck13vwz8ex+B9Xmi1W2GoaDq0f2XVbJhuEsB/jUf8APSPJK+vI4OCOAuDzVUHbIjhtpDKc+mD1/CvkFJwnzRP6czDD08RTlQqq8X/Xya3T6M+oZfhn/wAIFq9l8U/hyj+K/Bsyy+YLVs3cVvcRtFKhC4YsqudrgBlIw4X7x4nxVNoXh+ytdc8J+JJPE/h6RzHJbzzeTqumk9PKfIljOMjco8skYdWyDXfa5q3xk+FPjo+IEWx0+y1gx+bJHkaLdzKmC8nT7PLKR8xJUhuSxXJF3VfjH8INTvZH+I/w/aHXYG2zqkMUmXHPzMWiZgeo3g5Hcjk+zyw1ivdfnf8AD17P5H5A6uLk4VpL20Wt4uLbWukk7e9Ft+/Fr+8uh8oeNtKv9H16SDULmW9+0RxXcF1OSZJ7a4QPDI24khihAYEnDAjtWbHBt0HT7oDre3kWfokD/wDs9dP8T/G0vxB8VzeJTaCyt2iS2tYBzsggyFBIABOSSccAnA4FVY7cH4ZWl7jlPEFzFn2ktIm/9krGCXO+XY9OVSoqNJ1laWl152eh9bfsP4N14sPfNqPw/eV+gNfnl+w/ITrHiuLt5ds347nFfobX0lD4Efiuf/7/AFPl+SCiiiug+fP/0/1SooooAK+Bf2yONf8ADh9ba4/9DWvvqvgT9sr/AJD/AIb/AOva4/8AQ0rgx/8AAl8vzPuOCnbOaHz/APSWfHM5ziqpdkcSIxRkIZWHVSpyCPcHmrEvWqpbDgK21s8EdQRyD9R1r457n9S12fbPhrU/FfiCCa88OQpDrNzF52seENYQrZaorffu7PzeI2kPLgcB/vercL8avDWlaho/g2HRvDN94e1LUbptPCXQysIZ9ot2YsWYIxDQ8BRFkLwNokksPEHxn8PweKPh3qDQ6zo0/wBqvtGWQRNHeSrhryyl6qs+NxjLBd+7Hzfel8S618VLiPwV4r+Iwns7ez8Q29vPaXEKQ5miZSt0oADbXj3ggnAcEr8rAD3L3g00/Xp/wP60Pw6MHSxMZ05RjKLd43aknyuyt9tdm09NOZqx8/8Axh0aPw14/v8Aw1aoUtdLjt7W2yMFolhQ+Z7mRmZye7Ma0rey/wCLAx3rD/maiQfb7IyVT+NXiXUPE3xJ1qa+bKWNzLY26DpHDbuUAHuSCxPck+1egatpzaf+y7ozOMG71Zbv8JJJkX/x1RRRinUny7am2JqzhhsIqvxNwT+53PS/2Hif7e8VD/phbH/x56/RSvzn/Yc/5GDxT/1723/ob1+jFe5Q+BH5fxB/v9T5fkgoooroPnT/1P1SooooAK+A/wBso/8AE/8ADg9La4/9DWvvyvz8/bKf/ip/Dqf9Okx/OQVwY7+DL+up9vwX/wAjih8//SWfHMpJava7G/1OT4MSvpNvb3tnYyXNjq9tPGX8g3T+daX6YIKupLR789AAfl6eKSH5q7v4a+P7j4feIv7RaEXum3cZtdSsmAKXNs/3htbgsvVc+4PBNfK0pJS12Z/RGcUZ1aalTjzSi1JLvbpfo7N2fR2Z9BQ32veIfCl18QfAL3WtyzG3hvtGEnlzaSYiryG1eLE5R2QGJUwqqSSrn5R4h8UtV+Imu6JpWta/qN/faLcPKtkL2NYpILmL5XjmVERWkA+7JjDrkgKdyj2TUvhbrOlSRfFP9nDU3urC5Bb7JC37+IdWi2vxKqnrDIN69t3FeL/Er4sfEjx3aQeFfGVskLWs4lMUdpJDM8ygqu4MWPAY/KoAz2r06l1G0738tmfnOAjGdeNXCKEop682lSCtblatutFzK11vfc818cF5dfm1NfmOqRQXy+7XUauR/wB/Cy/UV9WfHbTI/DHwU0Lw2MA2txYW/HcxQSFj+JBNcJpXw4uLnx78PvDerxFZ4dKF/qUZHzRww3E06I/ofmWPB7muy/ax1ELoOhWZb5p9QmmI9ootufzlrqw9NxhObPAx+LjXxmDw9J3Su/uuk/8AyVv5l39hph/b3ile5gtj+G96/Rmvzf8A2F2B8ReKB3Nrbn/x9q/SCvUofAj4bP8A/fqny/JBRRRXQfPH/9X9UqKKKACvBvjp8G1+KulW0+nTJb6tpu/7O0n+rkV8Fo3IBI5AIODg545r3mis6kFUi4S2O7A42rgq8MVh3aUdj8avE/w58ceFb24s9Z0i5Q22PMeFfPjUNyCXi3AAjkZxXn/mIzFVYEjqAeRX60fFv4F+G/isIdRe6utF1y0TZbarp8jRXCpyQjFSpdATkDII5wRk18ceIv2bf2odJl8vRfE1j4otcnb/AGjDbzygDpu+2ROfykNeLLKle8Jfefq9DxFm1bFULvvF2/Bp/meFeEfH/iz4f6g2oeFb1rYyY86FhvgmA6CSM8HHYjDDsRXuY/a88aC2xPommyXI4Eu6YAeny7ifyauZb4JftMpHuuvDnhy4cdhY2yk/9+2UVmt8G/2npj5Vr4L8PR5/je0tcflJKw/StKeEr01ywnocGP4jyjHS9riMK3Lvpf701c97+B9vresw6r8VfFbCTUvETrFB8u0JZwEgBF/hRn+6O6qDk5yfJv2iND8X+N/HmjeHPDGl3N8be1ODGhEfnXDkld7YTIRATzwOTXR6b8Fv20PEKR6drPiuz8O2MSLGiWvkx7EUYCoLaIkBRwBvH1r6j+Dn7PWjfCy8l8R6pqt74m8RTxmJ9R1CRnMaNjckKOz7AxHJ3EnpkDIr0fY/u1TufDRzWUMY8bCK7JdErWS+SMT9mX4Hal8JNFvtR8SyRtrGrGMSRRHckEUeSqbv4mJYliOOgHTJ+oaKK3jFRVkeXicRPEVHWq7sKKKKo5j/2Q=="
];
const demoImageHashes = {};

figma.showUI(__html__, {
  width: PLUGIN_WIDTH,
  height: PLUGIN_HEIGHT,
  themeColors: true
});

figma.on("selectionchange", () => sendSelectionSummary());

figma.ui.onmessage = async (message) => {
  try {
    if (message.type === "ready") {
      const [settings, bridge] = await Promise.all([getSettings(), checkLocalBridge()]);
      figma.ui.postMessage({
        type: "init",
        settings: publicSettings(settings),
        bridge,
        selection: inspectSelection()
      });
      return;
    }

    if (message.type === "check-local-bridge") {
      figma.ui.postMessage({ type: "bridge-status", bridge: await checkLocalBridge() });
      return;
    }

    if (message.type === "inspect-selection") {
      sendSelectionSummary();
      return;
    }

    if (message.type === "save-settings") {
      const saved = await saveSettings(message.settings || {});
      figma.ui.postMessage({
        type: "settings-saved",
        settings: publicSettings(saved)
      });
      return;
    }

    if (message.type === "test-connection") {
      const settings = await mergeSettings(message.settings || {});
      await callModel(settings, {
        system: "Reply with the single word OK.",
        user: "Connection test"
      });
      figma.ui.postMessage({ type: "connection-result", ok: true });
      return;
    }

    if (message.type === "analyze-request") {
      figma.ui.postMessage({ type: "analysis-started" });
      const analysis = await analyzeRequest(message.payload || {});
      figma.ui.postMessage({ type: "analysis-result", analysis });
      return;
    }

    if (message.type === "extract-prd") {
      figma.ui.postMessage({ type: "prd-extraction-started" });
      try {
        const extraction = await extractPrdContent(message.source || "");
        figma.ui.postMessage({ type: "prd-extraction-result", extraction });
      } catch (error) {
        figma.ui.postMessage({
          type: "prd-extraction-error",
          message: error && error.message ? error.message : "PRD 内容提取失败"
        });
      }
      return;
    }

    if (message.type === "generate-design") {
      figma.ui.postMessage({ type: "generation-started" });
      const result = await generateDesign(message.payload || {});
      figma.ui.postMessage({ type: "generation-result", result });
      return;
    }

    if (message.type === "resize") {
      figma.ui.resize(PLUGIN_WIDTH, Math.max(560, Math.min(860, message.height || PLUGIN_HEIGHT)));
    }
  } catch (error) {
    figma.ui.postMessage({
      type: "plugin-error",
      message: error && error.message ? error.message : "插件执行失败，请重试。"
    });
  }
};

function sendSelectionSummary() {
  figma.ui.postMessage({ type: "selection-changed", selection: inspectSelection() });
}

function inspectSelection() {
  const selection = figma.currentPage.selection;
  if (!selection.length) {
    return {
      count: 0,
      mode: "demo",
      title: "未选择画布内容",
      detail: "将使用内置搜索结果页双列商卡母版",
      slotCount: 0,
      detectedSlots: []
    };
  }

  const resolved = resolveSourceSelection(selection);
  const classification = resolved.classification;
  const textNodes = classification.textNodes;
  const sceneNodes = classification.nodes;
  const controllableFieldKeys = new Set(collectFieldControlCapabilities(resolved.nodes).map((item) => item.fieldKey));
  const detectedSlots = FIELD_CATALOG
    .filter((field) =>
      controllableFieldKeys.has(field.key) ||
      sceneNodes.some((node) => fieldContainerNameMatches(node.name || "", field)) ||
      textNodes.some((node) => fieldTargetScore(node, field) >= 12)
    )
    .map((field) => `${field.slotNumber} ${field.label}`);
  const sceneRoots = resolveSceneRoots(resolved.nodes);

  const primary = selection[0];
  return {
    count: selection.length,
    mode: classification.mode,
    title: sceneRoots.length > 1 ? `已识别 ${sceneRoots.length} 个业务页面` : selection.length === 1 ? primary.name : `已选择 ${selection.length} 个图层`,
    detail: classification.mode === "complete"
      ? resolved.recovered
        ? `${primary.type} · 已向上识别「${resolved.nodes[0].name}」完整结构`
        : `${primary.type} · 完整商卡结构，将等距复用当前选区`
      : `${primary.type} · 当前为原子/局部图层，将自动补全真实场景`,
    slotCount: detectedSlots.length,
    detectedSlots
  };
}

function resolveSourceSelection(selection) {
  const direct = classifySelection(selection);
  if (direct.mode === "complete") {
    return { nodes: selection.slice(), classification: direct, recovered: false };
  }

  const commonAncestor = nearestCommonAncestor(selection);
  let candidate = selection.length === 1 ? selection[0].parent : commonAncestor;
  let depth = 0;
  while (candidate && candidate.type !== "PAGE" && depth < 10) {
    if (!candidate.getPluginData || !candidate.getPluginData("joybuy-card-copilot")) {
      const classification = classifySelection([candidate]);
      if (classification.mode === "complete") {
        return { nodes: [candidate], classification, recovered: true };
      }
    }
    candidate = candidate.parent;
    depth += 1;
  }

  return { nodes: selection.slice(), classification: direct, recovered: false };
}

function nearestCommonAncestor(nodes) {
  if (!nodes.length) return null;
  const firstPath = [];
  let current = nodes[0];
  while (current) {
    firstPath.push(current);
    current = current.parent;
  }
  return firstPath.find((candidate) => nodes.every((node) => isDescendantOrSelf(node, candidate))) || null;
}

function isDescendantOrSelf(node, ancestor) {
  let current = node;
  while (current) {
    if (current === ancestor) return true;
    current = current.parent;
  }
  return false;
}

function classifySelection(selection) {
  const bounds = selectionBounds(selection);
  const nodes = collectSceneNodes(selection, 1200);
  const textNodes = nodes.filter((node) => node.type === "TEXT");
  const searchable = nodes.map((node) => {
    const characters = node.type === "TEXT" ? node.characters : "";
    return `${node.name || ""} ${characters || ""}`.toLowerCase();
  });
  const signals = [
    /product[\s_-]*(picture|image)|商品图|main[\s_-]*image/,
    /product[\s_-]*(title|name)|商品名称|商品标题/,
    /(^|\s)price($|\s)|价格|£\s?\d|€\s?\d/,
    /rating|sold|销量|评分/,
    /add[\s_-]*(button|cart)|button|加购/,
    /seller|sold by|店铺|商家/
  ];
  const signalCount = signals.filter((pattern) => searchable.some((value) => pattern.test(value))).length;
  const largeEnough = Boolean(bounds && bounds.width >= 140 && bounds.height >= 340);
  const richEnough = textNodes.length >= 7 && nodes.length >= 12 && signalCount >= 3;
  return {
    mode: largeEnough && richEnough ? "complete" : "atom",
    bounds,
    nodes,
    textNodes,
    signalCount
  };
}

function collectSceneNodes(roots, limit) {
  const result = [];
  const stack = roots.slice();
  while (stack.length && result.length < limit) {
    const node = stack.shift();
    if (!node) continue;
    result.push(node);
    if ("children" in node) {
      for (const child of node.children) stack.push(child);
    }
  }
  return result;
}

async function getSettings() {
  const saved = await figma.clientStorage.getAsync(SETTINGS_KEY);
  return Object.assign({}, DEFAULT_SETTINGS, saved || {});
}

async function mergeSettings(next) {
  const current = await getSettings();
  return Object.assign({}, current, next, {
    apiKey: next.apiKey || current.apiKey || ""
  });
}

async function saveSettings(next) {
  const merged = await mergeSettings(next);
  await figma.clientStorage.setAsync(SETTINGS_KEY, merged);
  return merged;
}

function publicSettings(settings) {
  return {
    provider: settings.provider,
    endpoint: settings.endpoint,
    model: settings.model,
    authType: settings.authType || "",
    hasApiKey: Boolean(settings.apiKey)
  };
}

async function analyzeRequest(payload) {
  const fallback = buildFallbackAnalysis(payload);
  if (!payload.useAI) return fallback;

  const settings = await getSettings();
  if (!settings.endpoint || !settings.model || !settings.apiKey) return fallback;

  const selectionContext = buildSelectionContext();
  const prompt = [
    "你是 Joybuy 商卡设计系统专家。请把需求解析为严格 JSON，不要 Markdown。",
    "目标结构：",
    JSON.stringify({
      placement: fallback.placement,
      pageScopes: fallback.pageScopes,
      translations: DEFAULT_TRANSLATIONS,
      sceneTranslations: {
        de: { "Sort by": "Sortieren nach", "Get it by today": "Heute geliefert" },
        fr: { "Sort by": "Trier par", "Get it by today": "Livré aujourd’hui" }
      },
      overflow: { zh: "ellipsis", en: "wrap", de: "ellipsis", fr: "wrap", nl: "wrap", it: "wrap" },
      rationale: "一句中文说明",
      source: "PRD 优先或模型建议"
    }),
    `可选字段：${FIELD_CATALOG.map((field) => `${field.slotNumber} ${field.label}`).join("；")}`,
    "规则：根据 PRD 判断目标字段；PRD 提取内容是最高优先级，不得用示例文案覆盖；translations 只翻译目标字段；sceneTranslations 按画布原文精确映射其他可翻译文本，覆盖 ZH/EN/DE/FR/NL/IT，品牌、价格、SKU、数字、时间和图标保持不变；译文要简洁、符合电商语气；只返回 JSON。",
    `需求：${payload.requirement || "新增总促坑位满减 tag"}`,
    `设计师校验后的中文文案：${payload.promotionText || "未填写"}`,
    `PRD 原始输入：${payload.prd || "未提供"}`,
    `PRD 已提取正文：${payload.prdExtractedText || "未提取"}`,
    `PRD 已提取译文：${JSON.stringify(payload.translations || {})}`,
    `设计师已校验的页面范围（保持不变）：${JSON.stringify(payload.pageScopes || [])}`,
    `画布上下文：${JSON.stringify(selectionContext)}`
  ].join("\n");

  try {
    const raw = await callModel(settings, {
      system: "You are a product-card design-system expert. Output valid JSON only.",
      user: prompt
    });
    const parsed = parseJsonResponse(raw);
    const analysis = normalizeAnalysis(parsed, fallback);
    if (Array.isArray(payload.pageScopes)) analysis.pageScopes = normalizePageScopes(payload.pageScopes);
    return analysis;
  } catch (error) {
    figma.notify("模型调用失败，已切换为规则生成", { timeout: 2500 });
    return Object.assign({}, fallback, {
      modelWarning: error && error.message ? error.message : "模型调用失败"
    });
  }
}

function buildFallbackAnalysis(payload) {
  const promotionText = String(payload.promotionText || "").trim();
  const suppliedTranslations = payload.translations || {};
  const hasPrdCopy = Object.keys(suppliedTranslations).some((locale) => String(suppliedTranslations[locale] || "").trim());
  const translations = Object.assign({}, hasPrdCopy ? {} : DEFAULT_TRANSLATIONS, suppliedTranslations);
  if (promotionText) translations.zh = promotionText;
  const primaryCopy = promotionText || translations.zh || translations.en || "";
  for (const locale of Object.keys(DEFAULT_TRANSLATIONS)) {
    if (!String(translations[locale] || "").trim()) translations[locale] = primaryCopy || DEFAULT_TRANSLATIONS[locale];
  }
  const field = resolveFieldDefinition(payload.fieldKey || inferFieldFromText(`${payload.requirement || ""}\n${promotionText}`));
  const extractedScope = extractPageScopes(`${payload.requirement || ""}\n${payload.prdExtractedText || ""}`);
  return {
    placement: fieldPlacement(field, payload.fieldKey ? 1 : 0.84),
    targetVisible: payload.targetVisible !== false,
    pageScopes: Array.isArray(payload.pageScopes) ? normalizePageScopes(payload.pageScopes)
      : extractedScope.pageScopes,
    pageScopeEvidence: payload.pageScopeEvidence || extractedScope.pageScopeEvidence,
    translations,
    sceneTranslations: {},
    overflow: {
      zh: "ellipsis",
      en: "wrap",
      de: "wrap",
      fr: "wrap",
      nl: "wrap",
      it: "wrap"
    },
    rationale: `根据需求内容，建议修改字段 ${field.slotNumber}「${field.label}」。`,
    source: "内置商卡规则",
    usedAI: false
  };
}

async function extractPrdContent(source) {
  const rawSource = String(source || "").trim();
  if (!rawSource) throw new Error("请先粘贴 PRD 链接或正文");

  let sourceText = rawSource;
  let sourceType = "pasted-text";
  let sourceUrl = "";
  let documentSource = "pasted-text";
  if (/^https?:\/\/\S+$/i.test(rawSource)) {
    sourceType = "url";
    sourceUrl = rawSource;
    const document = await fetchPrdDocument(rawSource);
    sourceText = document.text;
    documentSource = document.source || "direct-request";
  }

  const fallback = extractPrdByRules(sourceText, sourceUrl);
  const settings = await getSettings();
  if (!settings.endpoint || !settings.model || !settings.apiKey) {
    return Object.assign({}, fallback, { sourceType, sourceUrl, documentSource, usedAI: false });
  }

  try {
    const raw = await callModel(settings, {
      system: "You extract product requirement content. Return valid JSON only and never invent copy.",
      user: [
        "从下面 PRD 正文提取商卡 Tag 需求。只返回 JSON。",
        JSON.stringify({
          requirement: "一句需求摘要",
          promotionText: "中文或主文案",
          targetFieldKey: "从 rankingBadge 到 actionButton 的字段键",
          pageScopes: ["正文明确涉及的页面名称；未说明则空数组"],
          translations: { zh: "", en: "", de: "", fr: "", nl: "", it: "" },
          evidence: "支持提取结果的原文片段"
        }),
        "规则：只使用正文中存在的文案；若某语言缺失，用主文案做忠实翻译；不要使用满 £50 减 £5 等示例；每条不超过 120 字。页面范围只提取本次生效的页面，排除不涉及、未来规划、历史背景；未知不要猜测。",
        `PRD 正文：\n${sourceText.slice(0, 18000)}`
      ].join("\n")
    });
    const parsed = parseJsonResponse(raw);
    return Object.assign(
      normalizePrdExtraction(parsed, fallback, sourceType, sourceUrl, sourceText),
      { documentSource }
    );
  } catch (error) {
    return Object.assign({}, fallback, {
      sourceType,
      sourceUrl,
      documentSource,
      usedAI: false,
      warning: error && error.message ? error.message : "模型提取失败，已使用规则提取"
    });
  }
}

async function fetchPrdDocument(url) {
  let response;
  try {
    response = await fetch(LOCAL_PRD_EXTRACT_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Joybuy-Bridge-Token": LOCAL_BRIDGE_TOKEN
      },
      body: JSON.stringify({ url })
    });
  } catch (error) {
    throw new Error("无法读取 PRD 链接。请先启动本地桥接，或直接粘贴 PRD 正文。");
  }
  const text = await response.text();
  let data = {};
  try { data = JSON.parse(text); } catch (error) { data = {}; }
  if (!response.ok) {
    throw new Error(data.error || (data.needsBrowserSync
      ? "请在 Chrome 打开该 PRD，点击 JoySpace PRD 同步扩展后重试。"
      : "PRD 链接读取失败，请稍后重试"));
  }
  if (!data.text || String(data.text).trim().length < 20) {
    throw new Error("PRD 正文为空，请等待页面加载完成并用 Chrome 扩展重新同步。");
  }
  return data;
}

const PAGE_SCOPE_ALIASES = [
  ["搜索", /搜索(?:结果)?(?:页)?|\bsearch(?: results)?(?: page)?\b/i],
  ["推荐", /首页推荐|推荐(?:页|流)?|\brecommendations?\b|\bhome feed\b/i],
  ["心愿单", /心愿单|愿望清单|\bwish ?list\b/i],
  ["购物车", /购物车|\b(?:shopping )?cart(?: page)?\b/i],
  ["商品详情", /商品详情(?:页)?|\bproduct details?(?: page)?\b|\bpdp\b/i],
  ["分类", /分类(?:页)?|品类页|\bcategor(?:y|ies)(?: page)?\b/i],
  ["首页", /首页|\bhome(?: ?page)?\b/i],
  ["订单", /订单(?:页|列表)?|\borders?(?: page)?\b/i]
];

function normalizePageScopes(value) {
  if (!Array.isArray(value)) return [];
  const result = [];
  for (const item of value) {
    if (typeof item !== "string") continue;
    const name = item.replace(/\s+/g, " ").trim().slice(0, 48);
    if (!name) continue;
    const known = PAGE_SCOPE_ALIASES.find(([, pattern]) => {
      const match = name.match(pattern);
      return match && match[0].length === name.length;
    });
    const canonical = known ? known[0] : name;
    if (!result.some((entry) => entry.toLowerCase() === canonical.toLowerCase())) result.push(canonical);
  }
  return result.slice(0, 12);
}

function extractPageScopes(text) {
  const lines = String(text || "").split(/[\n。；;]+/).map((line) => line.replace(/\*\*|^#{1,6}\s*/g, "").trim()).filter(Boolean);
  const scopeMarker = /页面范围|场域(?:范围)?|适用页面|涉及页面|适用范围|范围|\bpages?\s*(?:scope|:)|\bscope\b|\bsurfaces?\b/i;
  const excluded = /不涉及|不包含|不含|不在本次|不支持|不做|暂不|无需|排除|除外|后续|未来|历史|\bexclud|out.of.scope|not included|not supported|\bfuture\b|\bprevious\b/i;
  const explicitLines = [];
  let inScopeList = false;
  for (const line of lines) {
    if (scopeMarker.test(line) && !excluded.test(line.split(/[:：]/)[0])) {
      explicitLines.push(line);
      inScopeList = /[:：]\s*$/.test(line) || /^(?:页面范围|场域范围|scope)$/i.test(line);
    } else if (inScopeList && /^(?:[-*•]|\d+[.)、])\s*/.test(line)) explicitLines.push(line);
    else inScopeList = false;
  }
  const candidates = explicitLines.length ? explicitLines : lines.filter((line) =>
    /需求|本次|新增|增加|添加|支持|改动|修改|在|适用|\brequirement\b|\badd\b|\bshow\b|\bsupport\b|\bavailable\b/i.test(line));
  const found = [];
  const evidence = [];
  for (const line of candidates) {
    let excludedList = false;
    for (const clause of line.split(/[,，]/)) {
      if (/^(?:\s*)(?:本次|包含|涉及|包括|新增|in scope|include)/i.test(clause)) excludedList = false;
      if (excluded.test(clause)) excludedList = true;
      if (excludedList) continue;
      let remainder = clause;
      const clauseNames = [];
      for (const [name, pattern] of PAGE_SCOPE_ALIASES) {
        if (pattern.test(remainder)) {
          clauseNames.push(name);
          remainder = remainder.replace(new RegExp(pattern.source, "gi"), "");
        }
      }
      if (clauseNames.length) {
        found.push(...clauseNames);
        evidence.push(clause.trim());
      }
    }
  }
  return { pageScopes: normalizePageScopes(found), pageScopeEvidence: [...new Set(evidence)].join("；").slice(0, 480) };
}

function extractPrdByRules(text, sourceUrl) {
  const normalized = String(text || "").replace(/\r/g, "").replace(/[ \t]+/g, " ").trim();
  const lines = normalized.split("\n").map((line) => line.trim()).filter(Boolean);
  const translations = {};
  const aliases = {
    zh: /^(?:zh|cn|中文|简中)(?:\s*[:：|\-]\s*|\s+)/i,
    de: /^(?:de|german|deutsch)(?:\s*[:：|\-]\s*|\s+)/i,
    fr: /^(?:fr|french|français)(?:\s*[:：|\-]\s*|\s+)/i,
    nl: /^(?:nl|dutch|nederlands)(?:\s*[:：|\-]\s*|\s+)/i,
    en: /^(?:en|english)(?:\s*[:：|\-]\s*|\s+)/i,
    it: /^(?:it|italian|italiano|italiana|意大利语)(?:\s*[:：|\-]\s*|\s+)/i
  };
  for (const line of lines) {
    for (const locale of Object.keys(aliases)) {
      if (!translations[locale] && aliases[locale].test(line)) {
        const copy = line.replace(aliases[locale], "").replace(/^copy\s*[:：]?\s*/i, "").trim();
        if (copy && !/^(locale|copy|chars?)$/i.test(copy)) translations[locale] = copy.slice(0, 120);
      }
    }
  }

  const inlinePromotion = normalized.match(/满\s*[£€$¥￥]?\s*\d+(?:[.,]\d+)?\s*(?:元|英镑|欧元)?\s*(?:减|返)\s*[£€$¥￥]?\s*\d+(?:[.,]\d+)?/i);
  const commerceLine = lines.find((line) => /(?:buy|spend|save|gift|off|rabatt|remise|korting|cadeau|geschenk|sconto|spesa|regalo|满.+减|赠|礼)/i.test(line) && line.length <= 160);
  const promotionText = sanitizeTranslation(
    translations.zh || inlinePromotion && inlinePromotion[0] || translations.en || commerceLine || "",
    ""
  );
  if (!translations.zh && promotionText) translations.zh = promotionText;
  const title = lines.find((line) => line.length >= 4 && line.length <= 100) || "PRD 内容";
  const requirementLine = lines.find((line) => /(?:requirement|需求|tag|promotion|促销|总促)/i.test(line) && line.length <= 180);
  const targetField = inferFieldFromText(normalized);
  return {
    title,
    requirement: requirementLine || `根据 PRD 修改字段 ${targetField.slotNumber}「${targetField.label}」。`,
    promotionText,
    translations,
    evidence: commerceLine || promotionText || "已读取 PRD 正文，请人工校验文案。",
    extractedText: normalized.slice(0, 18000),
    sourceUrl: sourceUrl || "",
    targetFieldKey: targetField.key,
    ...extractPageScopes(normalized),
    usedAI: false
  };
}

function normalizePrdExtraction(parsed, fallback, sourceType, sourceUrl, sourceText) {
  const translations = {};
  const incoming = parsed && parsed.translations || {};
  for (const locale of Object.keys(DEFAULT_TRANSLATIONS)) {
    const value = sanitizeTranslation(incoming[locale], fallback.translations[locale] || "");
    if (value) translations[locale] = value;
  }
  const promotionText = sanitizeTranslation(parsed && parsed.promotionText, fallback.promotionText || translations.zh || "");
  if (promotionText && !translations.zh) translations.zh = promotionText;
  const scope = extractPageScopes(sourceText);
  const groundedScopes = normalizePageScopes(parsed && parsed.pageScopes).filter((name) => {
    if (scope.pageScopes.includes(name)) return true;
    if (PAGE_SCOPE_ALIASES.some(([known]) => known === name)) return false;
    return String(sourceText || "").split(/[\n。；;]+/).some((line) => line.includes(name)
      && /范围|场域|涉及|适用|scope|surfaces?/i.test(line)
      && !/不涉及|排除|后续|未来|历史|exclude|future/i.test(line));
  });
  return {
    title: sanitizeTranslation(parsed && parsed.title, fallback.title),
    requirement: sanitizeTranslation(parsed && parsed.requirement, fallback.requirement),
    promotionText,
    translations,
    evidence: sanitizeTranslation(parsed && parsed.evidence, fallback.evidence),
    extractedText: String(sourceText || "").slice(0, 18000),
    sourceType,
    sourceUrl,
    targetFieldKey: resolveFieldDefinition(parsed && parsed.targetFieldKey || fallback.targetFieldKey).key,
    pageScopes: normalizePageScopes([...scope.pageScopes, ...groundedScopes]),
    pageScopeEvidence: scope.pageScopeEvidence,
    usedAI: true
  };
}

function normalizeAnalysis(parsed, fallback) {
  const incomingTranslations = parsed.translations || parsed.content || {};
  const translations = {};
  for (const locale of Object.keys(DEFAULT_TRANSLATIONS)) {
    translations[locale] = sanitizeTranslation(
      incomingTranslations[locale],
      fallback.translations[locale]
    );
  }
  const incomingOverflow = parsed.overflow || {};
  const overflow = {};
  for (const locale of Object.keys(DEFAULT_TRANSLATIONS)) {
    overflow[locale] = incomingOverflow[locale] === "wrap" || incomingOverflow[locale] === "ellipsis"
      ? incomingOverflow[locale]
      : fallback.overflow[locale];
  }
  const incomingPlacement = parsed.placement || {};
  const field = resolveFieldDefinition(
    incomingPlacement.fieldKey || incomingPlacement.slotNumber || incomingPlacement.slotName || fallback.placement.fieldKey
  );
  return {
    placement: fieldPlacement(field, Number(incomingPlacement.confidence || fallback.placement.confidence || 0.9)),
    targetVisible: typeof parsed.targetVisible === "boolean" ? parsed.targetVisible : fallback.targetVisible !== false,
    pageScopes: normalizePageScopes(Array.isArray(parsed.pageScopes) ? parsed.pageScopes : fallback.pageScopes),
    pageScopeEvidence: String(parsed.pageScopeEvidence || fallback.pageScopeEvidence || "").slice(0, 480),
    translations,
    sceneTranslations: normalizeSceneTranslationPlan(parsed.sceneTranslations || fallback.sceneTranslations || {}),
    overflow,
    rationale: parsed.rationale || fallback.rationale,
    source: parsed.source || "模型解析",
    usedAI: parsed.usedAI === false ? false : true
  };
}

function normalizeSceneTranslationPlan(value) {
  const result = {};
  for (const locale of Object.keys(DEFAULT_TRANSLATIONS)) {
    const incoming = value && typeof value[locale] === "object" && !Array.isArray(value[locale]) ? value[locale] : {};
    result[locale] = {};
    for (const [source, translation] of Object.entries(incoming)) {
      const normalizedSource = String(source || "").trim().slice(0, 240);
      const normalizedTranslation = sanitizeSceneTranslation(translation);
      if (normalizedSource && normalizedTranslation) result[locale][normalizedSource] = normalizedTranslation;
    }
  }
  return result;
}

function sanitizeSceneTranslation(value) {
  if (typeof value !== "string") return "";
  return value.replace(/\s+/g, " ").trim().slice(0, 240);
}

function sanitizeTranslation(value, fallback) {
  if (typeof value !== "string") return String(fallback || "").trim();
  const normalized = value.replace(/\s+/g, " ").trim();
  return normalized ? normalized.slice(0, 120) : String(fallback || "").trim();
}

function resolveFieldDefinition(value) {
  if (value && typeof value === "object" && value.key) value = value.key;
  const normalized = String(value == null ? "" : value).trim().toLowerCase();
  const numeric = Number(normalized);
  return FIELD_CATALOG.find((field) => field.key.toLowerCase() === normalized) ||
    FIELD_CATALOG.find((field) => Number.isFinite(numeric) && field.slotNumber === numeric) ||
    FIELD_CATALOG.find((field) => {
      field.name.lastIndex = 0;
      return field.name.test(normalized) || field.label.toLowerCase() === normalized || field.english.toLowerCase() === normalized;
    }) ||
    FIELD_CATALOG.find((field) => field.key === "masterPromotion");
}

function fieldPlacement(fieldInput, confidence) {
  const field = resolveFieldDefinition(fieldInput);
  return {
    slotNumber: field.slotNumber,
    slotName: `${field.label} / ${field.english}`,
    fieldKey: field.key,
    confidence: Math.max(0, Math.min(1, Number(confidence) || 0.9))
  };
}

function inferFieldFromText(value) {
  const text = String(value || "").toLowerCase();
  let best = resolveFieldDefinition("masterPromotion");
  let bestScore = 0;
  for (const field of FIELD_CATALOG) {
    let score = 0;
    if (hasExplicitFieldNumber(text, field.slotNumber)) score += 6;
    field.name.lastIndex = 0;
    if (field.name.test(text)) score += 8;
    if (field.text) {
      field.text.lastIndex = 0;
      if (field.text.test(text)) score += 3;
    }
    if (score > bestScore) {
      best = field;
      bestScore = score;
    }
  }
  return best;
}

function buildSelectionContext() {
  const selection = figma.currentPage.selection;
  return selection.map((node) => {
    const texts = collectTextNodes([node], 120).map((textNode) => ({
      name: textNode.name,
      text: String(textNode.characters || "").slice(0, 120)
    }));
    return { name: node.name, type: node.type, texts };
  });
}

function collectLocalizableSceneTexts(roots, fieldInput) {
  const field = resolveFieldDefinition(fieldInput);
  const seen = new Set();
  const result = [];
  for (const node of collectTextNodes(roots, 5000)) {
    const source = String(node.characters || "").trim();
    if (!source || seen.has(source) || !shouldLocalizeSceneText(node, field)) continue;
    seen.add(source);
    result.push(source);
    if (result.length >= 160) break;
  }
  return result;
}

function shouldLocalizeSceneText(node, fieldInput) {
  const field = resolveFieldDefinition(fieldInput);
  const source = String(node && node.characters || "").trim();
  if (!source || !/[A-Za-z\u3400-\u9fff]/.test(source)) return false;
  if (!isNodeEffectivelyVisible(node)) return false;
  if (/^(?:https?:\/\/|www\.|[\w.+-]+@[\w.-]+)/i.test(source)) return false;
  if (/^(?:joybuy|joyexpress|joyplus(?: price)?|coca[ -]?cola|l['’]?or[eé]al|apple)$/i.test(source)) return false;
  if (/^[£€$¥￥]?\s*[\d.,:+×x%/\-–—]+\s*(?:ml|l|g|kg|cm|mm|gb|tb|pcs?)?$/i.test(source)) return false;
  if (/^[●◒▰★☆⌕‹›+\s]+$/.test(source)) return false;
  if (fieldTargetScore(node, field) >= 12) return false;
  for (const protectedKey of ["brandName", "sku", "price"]) {
    if (fieldTargetScore(node, resolveFieldDefinition(protectedKey)) >= 12) return false;
  }
  return true;
}

async function prepareSceneLocalizationPlan(roots, fieldInput, locales, existingPlan) {
  const field = resolveFieldDefinition(fieldInput);
  const sourceTexts = collectLocalizableSceneTexts(roots, field);
  const plan = normalizeSceneTranslationPlan(existingPlan || {});
  for (const locale of locales) {
    if (!plan[locale]) plan[locale] = {};
    for (const source of sourceTexts) {
      if (plan[locale][source]) continue;
      const builtIn = localizeSceneCopy(source, locale);
      if (builtIn && builtIn !== source) plan[locale][source] = builtIn;
    }
  }

  const unresolved = sourceTexts.filter((source) => locales.some((locale) =>
    !plan[locale][source] && needsSceneTranslation(source, locale)
  ));
  if (!unresolved.length) return plan;

  const settings = await getSettings();
  if (!settings.endpoint || !settings.model || !settings.apiKey) return plan;
  try {
    const raw = await callModel(settings, {
      system: "You localize Figma commerce UI copy. Return valid JSON only.",
      user: [
        "把以下 Figma 页面文本翻译到指定语言，只返回 JSON。",
        `目标语言：${locales.join(", ")}`,
        `目标字段 ${field.slotNumber} ${field.english} 已由设计师单独确认，不在本任务中修改。`,
        "输出结构：{\"sceneTranslations\":{\"zh\":{\"原文\":\"译文\"},\"en\":{},\"de\":{},\"fr\":{},\"nl\":{},\"it\":{}}}",
        "规则：键必须逐字使用给定原文；翻译商品标题、导航、筛选、促销、履约、销量和说明；品牌、价格、SKU、型号、数字、时间与符号保持不变；译文简洁自然；不要遗漏目标语言。",
        JSON.stringify(unresolved.slice(0, 120))
      ].join("\n")
    }, { maxTokens: 6000 });
    const parsed = parseJsonResponse(raw);
    const modelPlan = normalizeSceneTranslationPlan(parsed.sceneTranslations || parsed.translations || {});
    const sourceSet = new Set(sourceTexts);
    for (const locale of locales) {
      for (const [source, translation] of Object.entries(modelPlan[locale] || {})) {
        if (sourceSet.has(source) && translation) plan[locale][source] = translation;
      }
    }
  } catch (error) {
    // Built-in commerce terminology still provides deterministic localization when the model is unavailable.
  }
  return plan;
}

function needsSceneTranslation(source, locale) {
  if (locale === "en") return /[\u3400-\u9fff]/.test(source);
  return /[A-Za-z\u3400-\u9fff]/.test(source);
}

function localizeSceneCopy(source, locale) {
  const text = String(source || "").trim();
  if (!text || locale === "en") return text;
  const exact = SCENE_COPY_LIBRARY[text.toLowerCase()];
  if (exact && exact[locale]) return exact[locale];

  const dynamic = localizeDynamicCommerceCopy(text, locale);
  if (dynamic !== text) return dynamic;

  let translated = text;
  const phrases = Object.keys(SCENE_COPY_LIBRARY).sort((left, right) => right.length - left.length);
  for (const phrase of phrases) {
    const replacement = SCENE_COPY_LIBRARY[phrase][locale];
    if (!replacement || phrase.length < 4) continue;
    translated = translated.replace(new RegExp(escapeRegExp(phrase), "gi"), replacement);
  }
  return translated;
}

function localizeDynamicCommerceCopy(source, locale) {
  const words = {
    zh: { sold: "已售", save: "立省", onRrp: "（按建议零售价）", only: "仅剩", left: "件", per: "每", productsFound: "件商品" },
    de: { sold: "verkauft", save: "Spare", onRrp: "auf die UVP", only: "Nur noch", left: "verfügbar", per: "pro", productsFound: "Produkte gefunden" },
    fr: { sold: "vendus", save: "Économisez", onRrp: "sur le prix conseillé", only: "Plus que", left: "en stock", per: "pour", productsFound: "produits trouvés" },
    nl: { sold: "verkocht", save: "Bespaar", onRrp: "op de adviesprijs", only: "Nog", left: "op voorraad", per: "per", productsFound: "producten gevonden" },
    it: { sold: "venduti", save: "Risparmia", onRrp: "sul prezzo consigliato", only: "Solo", left: "disponibili", per: "per", productsFound: "prodotti trovati" }
  }[locale];
  if (!words) return source;
  let match = source.match(/^(.+?)\s*sold$/i);
  if (match) return locale === "zh" ? `${words.sold} ${match[1]}` : `${match[1]} ${words.sold}`;
  match = source.match(/^save\s+(.+?)\s+on\s+rrp$/i);
  if (match) return `${words.save} ${match[1]} ${words.onRrp}`;
  match = source.match(/^only\s+(\d+)\s+left$/i);
  if (match) return locale === "zh" ? `${words.only} ${match[1]} ${words.left}` : `${words.only} ${match[1]} ${words.left}`;
  match = source.match(/^([\d,.+]+)\s+products?\s+found$/i);
  if (match) return `${match[1]} ${words.productsFound}`;
  match = source.match(/^([£€$¥￥]?\s*[\d,.]+)\s+per\s+(.+)$/i);
  if (match) return locale === "zh" ? `${words.per}${match[2]} ${match[1]}` : `${match[1]} ${words.per} ${match[2]}`;
  match = source.match(/^rrp\s*:\s*(.+)$/i);
  if (match) {
    const labels = { zh: "建议零售价", de: "UVP", fr: "Prix conseillé", nl: "Adviesprijs", it: "Prezzo consigliato" };
    return `${labels[locale]}: ${match[1]}`;
  }
  match = source.match(/^was\s*:\s*(.+)$/i);
  if (match) {
    const labels = { zh: "原价", de: "Vorher", fr: "Ancien prix", nl: "Was", it: "Prima" };
    return `${labels[locale]}: ${match[1]}`;
  }
  match = source.match(/^excl\.?\s+deposit\s+(.+)$/i);
  if (match) {
    const labels = { zh: "另加押金", de: "Zzgl. Pfand", fr: "Hors consigne", nl: "Excl. statiegeld", it: "Deposito escluso" };
    return `${labels[locale]} ${match[1]}`;
  }
  return source;
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

async function localizeSceneTextNodes(roots, locale, fieldInput, plan) {
  const field = resolveFieldDefinition(fieldInput);
  let changed = 0;
  for (const node of collectTextNodes(roots, 5000)) {
    if (!shouldLocalizeSceneText(node, field)) continue;
    const source = String(node.characters || "").trim();
    const translation = plan && plan[locale] && plan[locale][source] || localizeSceneCopy(source, locale);
    if (!translation || translation === source) continue;
    try {
      await loadTextFonts(node);
      node.characters = translation;
      applyOverflow(node, chooseOverflow("auto", "wrap", translation, node.width, numericFontSize(node)));
      changed += 1;
    } catch (error) {
      // Preserve generation when a library-owned text override is read-only.
    }
  }
  return changed;
}

async function callModel(settings, prompt, options) {
  const endpoint = String(settings.endpoint || "").trim();
  const model = String(settings.model || "").trim();
  const apiKey = String(settings.apiKey || "").trim();
  const provider = resolveProvider(settings.provider, endpoint);
  const maxTokens = Math.max(400, Math.min(8000, Number(options && options.maxTokens) || (provider === "gemini" ? 4096 : 1200)));
  if (!endpoint || !model || !apiKey) {
    throw new Error("请先补全 API 地址、模型名称与 API Key");
  }

  const headers = { "Content-Type": "application/json" };
  let body;

  if (provider === "gemini") {
    const nativeEndpoint = /\/models\/[^/?]+:(?:generateContent|streamGenerateContent)(?:\?|$)/i.test(endpoint);
    const authType = settings.authType || (nativeEndpoint ? "google-api-key" : "bearer");
    if (authType === "google-api-key") headers["x-goog-api-key"] = apiKey;
    else if (authType === "api-key") headers["x-api-key"] = apiKey;
    else headers.Authorization = `Bearer ${apiKey}`;
    body = {
      systemInstruction: { parts: [{ text: prompt.system }] },
      contents: [{ role: "user", parts: [{ text: prompt.user }] }],
      generationConfig: { maxOutputTokens: maxTokens }
    };
    if (!nativeEndpoint) body.model = model;
  } else if (provider === "anthropic-messages") {
    headers["x-api-key"] = apiKey;
    headers["anthropic-version"] = "2023-06-01";
    body = {
      model,
      max_tokens: maxTokens,
      system: prompt.system,
      messages: [{ role: "user", content: prompt.user }]
    };
  } else if (provider === "openai-chat") {
    headers.Authorization = `Bearer ${apiKey}`;
    body = {
      model,
      max_tokens: maxTokens,
      messages: [
        { role: "system", content: prompt.system },
        { role: "user", content: prompt.user }
      ]
    };
  } else {
    headers.Authorization = `Bearer ${apiKey}`;
    body = {
      model,
      max_output_tokens: maxTokens,
      instructions: prompt.system,
      input: prompt.user,
      stream: false
    };
  }

  const request = {
      method: "POST",
      headers,
      body: JSON.stringify(body)
    };
  const requestEndpoint = provider === "gemini"
    ? endpoint.replace(/:streamGenerateContent(?=\?|$)/i, ":generateContent").replace(/([?&])alt=sse(?=&|$)/i, "$1").replace(/\?&/, "?").replace(/[?&]$/, "")
    : endpoint;
  const response = await fetchModelResponse(requestEndpoint, request);
  const text = await response.text();
  if (!response.ok) {
    throw new Error(`API ${response.status}: ${text.slice(0, 180)}`);
  }

  let data;
  try {
    data = JSON.parse(text);
  } catch (error) {
    if (provider === "gemini") throw new Error("Gemini 返回了非 JSON 内容，请检查接口地址和协议类型。");
    return text;
  }

  const modelText = extractModelText(data);
  if (provider === "gemini" && !modelText.trim()) {
    const reason = data && (data.promptFeedback && data.promptFeedback.blockReason
      || data.candidates && data.candidates[0] && data.candidates[0].finishReason);
    throw new Error(`Gemini 未返回可用文本${reason ? `（${String(reason).slice(0, 80)}）` : ""}。请检查权限、接口格式或输出上限。`);
  }
  return modelText || text;
}

function resolveProvider(provider, endpoint) {
  if (provider && provider !== "auto") return provider;
  if (/:(?:generateContent|streamGenerateContent)(?:\?|$)/i.test(endpoint)) return "gemini";
  if (/\/messages(?:\?|$)/i.test(endpoint)) return "anthropic-messages";
  if (/\/chat\/completions(?:\?|$)/i.test(endpoint)) return "openai-chat";
  return "openai-responses";
}

async function fetchModelResponse(endpoint, request) {
  if (shouldUseLocalBridge(endpoint)) {
    return fetchModelResponseWithRetry(() => fetchThroughLocalBridge(endpoint, request));
  }

  try {
    return await fetchModelResponseWithRetry(() => fetch(endpoint, request));
  } catch (directError) {
    try {
      return await fetchModelResponseWithRetry(() => fetchThroughLocalBridge(endpoint, request));
    } catch (bridgeError) {
      if (bridgeError && /^本地桥接失败：/.test(bridgeError.message || "")) {
        throw new Error(`${bridgeError.message}（模型接口直连也失败）`);
      }
      throw new Error("无法连接模型服务，且本地桥接不可用。请启动本地桥接后重试。");
    }
  }
}

async function fetchModelResponseWithRetry(fetcher) {
  let lastResponse = null;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const response = await fetcher();
      lastResponse = response;
      if (response.status !== 429 && response.status < 500) return response;
    } catch (error) {
      if (attempt === 1) throw error;
    }
    await delay(650 * (attempt + 1));
  }
  return lastResponse;
}

function extractModelText(data) {
  if (!data || typeof data !== "object") return "";
  if (typeof data.output_text === "string") return data.output_text;
  if (typeof data.response === "string") return data.response;
  if (typeof data.result === "string") return data.result;

  if (Array.isArray(data.output)) {
    const output = data.output
      .flatMap((item) => item && Array.isArray(item.content) ? item.content : [])
      .map((item) => typeof item === "string" ? item : item && (item.text || item.output_text) || "")
      .filter(Boolean)
      .join("\n");
    if (output) return output;
  }

  if (Array.isArray(data.content)) {
    const content = data.content
      .map((item) => typeof item === "string" ? item : item && item.text || "")
      .filter(Boolean)
      .join("\n");
    if (content) return content;
  }

  const choice = data.choices && data.choices[0];
  if (choice) {
    if (typeof choice.text === "string") return choice.text;
    const content = choice.message && choice.message.content;
    if (typeof content === "string") return content;
    if (Array.isArray(content)) {
      return content.map((item) => typeof item === "string" ? item : item && item.text || "").filter(Boolean).join("\n");
    }
  }

  const candidate = data.candidates && data.candidates[0];
  if (candidate && candidate.content && Array.isArray(candidate.content.parts)) {
    return candidate.content.parts.filter((part) => part && !part.thought && typeof part.text === "string").map((part) => part.text).filter(Boolean).join("\n");
  }
  return "";
}

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

function shouldUseLocalBridge(endpoint) {
  try {
    const url = new URL(endpoint);
    const hostname = url.hostname.toLowerCase();
    return url.protocol === "http:" ||
      hostname === "localhost" ||
      hostname.endsWith(".local") ||
      /^10\./.test(hostname) ||
      /^127\./.test(hostname) ||
      /^192\.168\./.test(hostname) ||
      /^172\.(1[6-9]|2\d|3[01])\./.test(hostname);
  } catch (error) {
    return false;
  }
}

async function checkLocalBridge() {
  try {
    const response = await fetch("http://localhost:3210/health");
    const data = await response.json();
    return {
      ok: response.ok && data && data.ok === true,
      version: data.version || "",
      authenticatedPrdCount: Number(data.authenticatedPrdCount || 0),
      latestPrdSyncAt: data.latestPrdSyncAt || ""
    };
  } catch (error) {
    return { ok: false, version: "", authenticatedPrdCount: 0, latestPrdSyncAt: "" };
  }
}

async function fetchThroughLocalBridge(endpoint, request) {
  let response;
  try {
    response = await fetch(LOCAL_BRIDGE_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Joybuy-Bridge-Token": LOCAL_BRIDGE_TOKEN
      },
      body: JSON.stringify({
        url: endpoint,
        headers: request.headers,
        body: request.body
      })
    });
  } catch (error) {
    throw new Error("无法连接本地桥接。请双击 plugin/启动本地桥接.command，保持终端窗口开启，再点击“检测连接”。");
  }

  if (response.status === 403 || response.status === 502) {
    const detail = await response.text();
    try {
      const parsed = JSON.parse(detail);
      throw new Error(`本地桥接失败：${parsed.error || detail}`);
    } catch (error) {
      if (error.message.startsWith("本地桥接失败：")) throw error;
      throw new Error(`本地桥接失败：${detail.slice(0, 180)}`);
    }
  }
  return response;
}

function parseJsonResponse(raw) {
  const cleaned = String(raw || "")
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/, "")
    .trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start < 0 || end < start) throw new Error("模型未返回可解析的 JSON");
  return JSON.parse(cleaned.slice(start, end + 1));
}

async function generateDesign(payload) {
  const analysis = normalizeAnalysis(payload.analysis || {}, buildFallbackAnalysis(payload));
  const locales = Array.isArray(payload.locales) && payload.locales.length
    ? payload.locales
    : ["zh", "en", "de", "fr", "nl", "it"];
  const rawSelection = figma.currentPage.selection
    .filter((node) => !node.getPluginData("joybuy-card-copilot"))
    .slice();
  const resolvedSelection = rawSelection.length
    ? resolveSourceSelection(rawSelection)
    : { nodes: [], classification: { mode: "demo" }, recovered: false };
  const selected = resolvedSelection.nodes;
  const selectionInfo = resolvedSelection.classification;
  const shouldReuseSelection = selectionInfo.mode === "complete";
  const field = resolveFieldDefinition(analysis.placement.fieldKey || analysis.placement.slotNumber);
  const localizationPlan = shouldReuseSelection
    ? await prepareSceneLocalizationPlan(selected, field, locales, analysis.sceneTranslations)
    : normalizeSceneTranslationPlan(analysis.sceneTranslations || {});
  const headerContent = buildDesignHeaderContent(payload, analysis);
  const board = shouldReuseSelection
    ? await buildFromSelection(selected, analysis, locales, payload.overflowMode, headerContent, localizationPlan)
    : await buildDemoBoard(analysis, locales, payload.overflowMode, headerContent, localizationPlan);

  board.setPluginData("joybuy-card-copilot", JSON.stringify({
    requirement: payload.requirement || "新增满减总促 tag",
    placement: analysis.placement,
    pageScopes: normalizePageScopes(analysis.pageScopes),
    locales,
    createdAt: new Date().toISOString()
  }));

  figma.currentPage.selection = [board];
  figma.viewport.scrollAndZoomIntoView([board]);
  figma.notify(
    shouldReuseSelection
      ? `已基于当前商卡生成 ${locales.length} 个语言版本`
      : `已自动补全搜索结果页并生成 ${locales.length} 个语言版本`,
    { timeout: 2800 }
  );
  return {
    nodeId: board.id,
    localeCount: locales.length,
    usedSelection: shouldReuseSelection,
    sourceMode: shouldReuseSelection
      ? resolvedSelection.recovered ? "ancestor-selection" : "selection"
      : rawSelection.length ? "atom-to-scene" : "demo",
    fieldControlsEnabled: Number(board.getPluginData("joybuy-field-controls") || 0),
    totalPromotionControlsEnabled: Number(board.getPluginData("joybuy-field-controls") || 0),
    changedTargetCount: Number(board.getPluginData("joybuy-changed-targets") || 0),
    localizedTextCount: Number(board.getPluginData("joybuy-localized-texts") || 0),
    missingTargetCount: Number(board.getPluginData("joybuy-missing-targets") || 0),
    sceneCount: Number(board.getPluginData("joybuy-scene-count") || (shouldReuseSelection ? selected.length : 1)),
    fieldLabel: analysis.placement.slotName,
    title: board.name
  };
}

function buildDesignHeaderContent(payload, analysis) {
  const field = resolveFieldDefinition(analysis.placement.fieldKey || analysis.placement.slotNumber);
  const rawRequirement = String(payload.requirement || "").trim();
  const requirement = rawRequirement.split(/\r?\n/).map((line) => line.trim()).find(Boolean) || `${field.label}需求`;
  const prdValue = String(payload.prd || "").trim();
  const prdUrlMatch = prdValue.match(/https?:\/\/[^\s]+/i);
  return {
    requirement,
    prdUrl: prdUrlMatch ? prdUrlMatch[0] : ""
  };
}

async function buildFromSelection(selection, analysis, locales, overflowMode, headerContent, localizationPlan) {
  const sceneLayout = buildNormalizedSceneLayout(selection, 32, 16);
  if (!sceneLayout.scenes.length) return buildDemoBoard(analysis, locales, overflowMode, headerContent, localizationPlan);

  const field = resolveFieldDefinition(analysis.placement.fieldKey || analysis.placement.slotNumber);
  const cardWidth = sceneLayout.width;
  const cardHeight = sceneLayout.height;
  const columnGap = 24;
  const outerPadding = 24;
  const headerHeight = DESIGN_HEADER_HEIGHT;
  const localeHeader = 36;
  const board = figma.createFrame();
  board.name = `AI 商卡设计 · ${field.label} · 多语言`;
  board.resize(
    outerPadding * 2 + locales.length * cardWidth + (locales.length - 1) * columnGap,
    headerHeight + outerPadding + localeHeader + cardHeight + outerPadding
  );
  board.x = figma.viewport.center.x - board.width / 2;
  board.y = figma.viewport.center.y - board.height / 2;
  board.fills = [solid("F7F7F9")];
  board.cornerRadius = 0;
  board.clipsContent = false;

  await addBoardHeader(board, headerContent);
  let totalVisibilityChanges = 0;
  let totalChangedTargets = 0;
  let totalMissingTargets = 0;
  let totalLocalizedTexts = 0;

  for (let index = 0; index < locales.length; index += 1) {
    const locale = locales[index];
    const localeFrame = createLocaleFrame(cardWidth, cardHeight + localeHeader);
    localeFrame.name = `${LOCALE_LABELS[locale] || locale} · ${field.label}`;
    localeFrame.x = outerPadding + index * (cardWidth + columnGap);
    localeFrame.y = headerHeight + outerPadding;
    board.appendChild(localeFrame);
    await addLocaleHeader(localeFrame, locale, analysis.translations[locale]);

    for (const scene of sceneLayout.scenes) {
      const clone = scene.node.clone();
      localeFrame.appendChild(clone);
      clone.x = scene.x;
      clone.y = localeHeader;

      const targetVisible = analysis.targetVisible !== false;
      totalLocalizedTexts += await localizeSceneTextNodes([clone], locale, field, localizationPlan);
      const visibilityChanges = setFieldVisibility([clone], field, targetVisible);
      totalVisibilityChanges += visibilityChanges;
      const copy = analysis.translations[locale] || analysis.translations.zh;
      let changed = targetVisible
        ? await updateFieldTargets(
          [clone],
          localeFrame,
          field,
          locale,
          copy,
          chooseOverflow(
            overflowMode,
            analysis.overflow[locale],
            copy,
            candidateWidthFallback([clone], field)
          )
        )
        : 0;
      if (targetVisible && !changed) {
        changed = await highlightStructuralFieldTargets([clone], localeFrame, field);
      }
      totalChangedTargets += changed;
      if (targetVisible && !changed) {
        await addMissingFieldNotice(localeFrame, scene.x, field);
        totalMissingTargets += 1;
      }
    }
  }
  board.setPluginData("joybuy-field-controls", String(totalVisibilityChanges));
  board.setPluginData("joybuy-changed-targets", String(totalChangedTargets));
  board.setPluginData("joybuy-missing-targets", String(totalMissingTargets));
  board.setPluginData("joybuy-localized-texts", String(totalLocalizedTexts));
  board.setPluginData("joybuy-scene-count", String(sceneLayout.scenes.length));
  return board;
}

function buildNormalizedSceneLayout(selection, gap, padding) {
  const safeGap = Number(gap) || 32;
  const safePadding = Number(padding) || 16;
  const scenes = resolveSceneRoots(selection)
    .map((node) => ({ node, bounds: node && node.absoluteBoundingBox }))
    .filter((scene) => Boolean(scene.bounds))
    .sort((left, right) => left.bounds.x - right.bounds.x || left.bounds.y - right.bounds.y);
  let cursorX = safePadding;
  let maxHeight = 0;
  for (const scene of scenes) {
    scene.x = cursorX;
    cursorX += scene.bounds.width + safeGap;
    maxHeight = Math.max(maxHeight, scene.bounds.height);
  }
  return {
    scenes,
    width: scenes.length ? cursorX - safeGap + safePadding : 0,
    height: Math.max(240, maxHeight) + safePadding
  };
}

function resolveSceneRoots(selection) {
  if (!Array.isArray(selection) || selection.length !== 1) return Array.isArray(selection) ? selection.slice() : [];
  const root = selection[0];
  if (!root || !("children" in root) || !root.absoluteBoundingBox) return selection.slice();
  const candidates = root.children.filter((child) => {
    const bounds = child.absoluteBoundingBox;
    if (!bounds || bounds.width < 280 || bounds.height < 500) return false;
    return classifySelection([child]).mode === "complete";
  });
  if (candidates.length < 2) return selection.slice();
  const maxChildWidth = Math.max(...candidates.map((child) => child.absoluteBoundingBox.width));
  return root.absoluteBoundingBox.width >= maxChildWidth * 1.8 ? candidates : selection.slice();
}

async function buildDemoBoard(analysis, locales, overflowMode, headerContent, localizationPlan) {
  const screenWidth = 375;
  const screenHeight = 780;
  const gap = 24;
  const padding = 24;
  const headerHeight = DESIGN_HEADER_HEIGHT;
  const board = figma.createFrame();
  board.name = "AI 商卡设计 · 搜索结果页演示 · 多语言";
  board.resize(
    padding * 2 + locales.length * screenWidth + (locales.length - 1) * gap,
    headerHeight + padding + screenHeight + padding
  );
  board.x = figma.viewport.center.x - board.width / 2;
  board.y = figma.viewport.center.y - board.height / 2;
  board.fills = [solid("F7F7F9")];
  board.cornerRadius = 0;
  board.clipsContent = false;
  await addBoardHeader(board, headerContent);
  board.setPluginData("joybuy-field-controls", "0");
  board.setPluginData("joybuy-scene-count", "1");
  let totalChangedTargets = 0;
  let totalLocalizedTexts = 0;

  for (let index = 0; index < locales.length; index += 1) {
    const locale = locales[index];
    const screen = figma.createFrame();
    screen.name = `${LOCALE_LABELS[locale] || locale} · 搜索结果页`;
    screen.resize(screenWidth, screenHeight);
    screen.x = padding + index * (screenWidth + gap);
    screen.y = headerHeight + padding;
    screen.fills = [solid("FFFFFF")];
    screen.cornerRadius = 16;
    screen.clipsContent = false;
    board.appendChild(screen);
    totalChangedTargets += await drawDemoScreen(screen, locale, analysis, overflowMode);
    totalLocalizedTexts += await localizeSceneTextNodes(
      [screen],
      locale,
      resolveFieldDefinition(analysis.placement.fieldKey || analysis.placement.slotNumber),
      localizationPlan
    );
  }
  board.setPluginData("joybuy-changed-targets", String(totalChangedTargets));
  board.setPluginData("joybuy-localized-texts", String(totalLocalizedTexts));
  return board;
}

async function addBoardHeader(board, headerContent) {
  const horizontalPadding = board.width >= 900 ? 72 : 32;
  const titleSize = board.width >= 900 ? 52 : 36;
  const metaSize = board.width >= 900 ? 18 : 13;
  const header = figma.createFrame();
  header.name = "需求标题头 · Joybuy";
  header.resize(board.width, DESIGN_HEADER_HEIGHT);
  header.x = 0;
  header.y = 0;
  header.fills = [solid("101010")];
  header.clipsContent = true;
  board.appendChild(header);

  const wordmark = figma.createNodeFromSvg(JOYBUY_WORDMARK_SVG);
  wordmark.name = "Joybuy Wordmark";
  wordmark.resize(110, 30);
  wordmark.x = horizontalPadding;
  wordmark.y = 48;
  header.appendChild(wordmark);

  const title = await makeText(headerContent.requirement || "需求名称", titleSize, "Bold", "FFFFFF");
  title.name = "需求名称";
  title.textAutoResize = "TRUNCATE";
  title.resize(Math.max(180, board.width - horizontalPadding * 2), titleSize * 1.45);
  title.x = horizontalPadding;
  title.y = 126;
  header.appendChild(title);

  const metadata = figma.createFrame();
  metadata.name = "需求信息 · UX / PM / Xingyun / PRD";
  metadata.resize(Math.max(180, board.width - horizontalPadding * 2), 32);
  metadata.x = horizontalPadding;
  metadata.y = 264;
  metadata.fills = [];
  metadata.clipsContent = true;
  header.appendChild(metadata);

  let cursorX = 0;
  const appendMetadataText = async (characters, name, gapAfter) => {
    const text = await makeText(characters, metaSize, "Regular", "D7D7DA");
    text.name = name;
    text.x = cursorX;
    text.y = 5;
    metadata.appendChild(text);
    cursorX += text.width + gapAfter;
    return text;
  };
  const appendLinkIcon = (name) => {
    const icon = figma.createNodeFromSvg(LINK_ICON_SVG);
    icon.name = name;
    icon.resize(16, 16);
    icon.x = cursorX;
    icon.y = 6;
    metadata.appendChild(icon);
    cursorX += 20;
  };

  await appendMetadataText("UX: @Beta", "UX", 28);
  await appendMetadataText("PM: @Mike", "PM", 28);
  await appendMetadataText("Xingyun:", "Xingyun", 6);
  appendLinkIcon("Xingyun Link Icon");
  await appendMetadataText("Link", "Xingyun Link", 28);
  await appendMetadataText("PRD:", "PRD", 6);
  appendLinkIcon("PRD Link Icon");
  const prdLink = await appendMetadataText("Doc Link", "PRD Doc Link", 0);
  if (headerContent.prdUrl) {
    prdLink.setPluginData("joybuy-prd-url", headerContent.prdUrl);
    if (typeof prdLink.setRangeHyperlink === "function") {
      prdLink.setRangeHyperlink(0, prdLink.characters.length, { type: "URL", value: headerContent.prdUrl });
    }
  }
}

function createLocaleFrame(width, height) {
  const frame = figma.createFrame();
  frame.resize(width, height);
  frame.fills = [solid("FFFFFF")];
  frame.cornerRadius = 16;
  frame.clipsContent = false;
  return frame;
}

async function addLocaleHeader(frame, locale, translation) {
  const label = await makeText(LOCALE_LABELS[locale] || locale.toUpperCase(), 11, "Bold", "3F3F46");
  label.x = 12;
  label.y = 11;
  frame.appendChild(label);
  const preview = await makeText(String(translation || ""), 10, "Regular", "767680");
  preview.textAutoResize = "TRUNCATE";
  preview.resize(Math.max(80, frame.width - label.width - 34), 14);
  preview.x = label.width + 22;
  preview.y = 11;
  frame.appendChild(preview);
}

async function updateFieldTargets(roots, localeFrame, field, locale, copy, overflow) {
  const rankedCandidates = collectTextNodes(roots, 5000)
    .map((node) => ({ node, score: fieldTargetScore(node, field) }))
    .filter((item) => item.score >= 12 && isNodeEffectivelyVisible(item.node))
    .sort((a, b) => b.score - a.score)
    .slice(0, 600);
  const candidates = dedupeFieldCandidatesByOwner(rankedCandidates);
  if (!candidates.length) return 0;

  let changed = 0;
  let hasLabeledHighlight = false;
  for (const candidate of candidates) {
    try {
      await loadTextFonts(candidate.node);
      candidate.node.characters = String(copy || DEFAULT_TRANSLATIONS[locale] || DEFAULT_TRANSLATIONS.zh);
      const strategy = chooseOverflow("auto", overflow, candidate.node.characters, candidate.node.width, numericFontSize(candidate.node));
      applyOverflow(candidate.node, strategy);
      const highlighted = await addHighlight(localeFrame, candidate.node, !hasLabeledHighlight, field);
      if (highlighted) hasLabeledHighlight = true;
      changed += 1;
    } catch (error) {
      // Some locked or library-owned nested nodes cannot accept overrides.
    }
  }
  return changed;
}

function dedupeFieldCandidatesByOwner(candidates) {
  const result = [];
  const seen = new Set();
  for (const candidate of candidates) {
    const owner = nearestSemanticFieldOwner(candidate.node);
    const key = owner ? `owner:${owner.node.id}` : `node:${candidate.node.id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    result.push(candidate);
  }
  return result;
}

function enableTotalPromotionControls(roots) {
  return enableFieldControls(roots, resolveFieldDefinition("masterPromotion"));
}

function enableFieldControls(roots, fieldInput) {
  return setFieldVisibility(roots, fieldInput, true);
}

function disableFieldControls(roots, fieldInput) {
  return setFieldVisibility(roots, fieldInput, false);
}

function setFieldVisibility(roots, fieldInput, visible) {
  const field = resolveFieldDefinition(fieldInput);
  const stack = roots.slice();
  let changed = 0;
  while (stack.length) {
    const node = stack.shift();
    if (!node) continue;
    if (protectedNonCatalogFieldContainerMatches(node.name || "")) continue;

    const componentProperties = node.type === "INSTANCE"
      ? getComponentPropertiesSafely(node)
      : null;
    if (componentProperties && typeof node.setProperties === "function") {
      const updates = buildFieldPropertyUpdates(componentProperties, field, visible);
      const keys = Object.keys(updates);
      if (keys.length) {
        try {
          node.setProperties(updates);
          changed += keys.length;
        } catch (error) {
          // Preserve generation when a remote library instance rejects an override.
        }
      }
    }

    const nodeName = String(node.name || "").toLowerCase();
    if ("visible" in node && node.visible !== visible && isFieldNodeName(nodeName, field)) {
      try {
        node.visible = visible;
        changed += 1;
      } catch (error) {
        // Preserve generation when visibility is read-only.
      }
    }

    if ("children" in node) {
      for (const child of node.children) stack.push(child);
    }
  }
  return changed;
}

function buildFieldPropertyUpdates(componentProperties, fieldInput, visible) {
  const field = resolveFieldDefinition(fieldInput);
  const matches = Object.keys(componentProperties || {}).filter((propertyName) =>
    isFieldVisibilityProperty(propertyName, componentProperties[propertyName], field)
  );
  const updates = {};
  if (!visible) {
    for (const propertyName of matches) {
      if (componentProperties[propertyName].value !== false) updates[propertyName] = false;
    }
    return updates;
  }

  const preferences = EXCLUSIVE_FIELD_CONTROL_PREFERENCES[field.key];
  if (preferences && matches.length > 1) {
    const alreadyVisible = matches.some((propertyName) => componentProperties[propertyName].value === true);
    if (alreadyVisible) return updates;
    const preferred = preferences
      .map((pattern) => matches.find((propertyName) => pattern.test(normalizeComponentControlName(propertyName))))
      .find(Boolean);
    if (preferred) updates[preferred] = true;
    return updates;
  }

  for (const propertyName of matches) {
    if (componentProperties[propertyName].value !== true) updates[propertyName] = true;
  }
  return updates;
}

function getComponentPropertiesSafely(node) {
  try {
    return node.componentProperties || null;
  } catch (error) {
    return null;
  }
}

function isTotalPromotionVisibilityProperty(propertyName, property) {
  return isFieldVisibilityProperty(propertyName, property, resolveFieldDefinition("masterPromotion"));
}

function isTotalPromotionName(name) {
  return isFieldNodeName(name, resolveFieldDefinition("masterPromotion"));
}

function isFieldVisibilityProperty(propertyName, property, fieldInput) {
  const field = resolveFieldDefinition(fieldInput);
  if (!property || property.type !== "BOOLEAN") return false;
  return matchesFieldComponentProperty(propertyName, field);
}

function isFieldNodeName(name, fieldInput) {
  const field = resolveFieldDefinition(fieldInput);
  const normalized = normalizeComponentControlName(name);
  if (field.key === "masterPromotion" && /individual|single|单促/.test(normalized)) return false;
  const matches = fieldKeysForLayerName(normalized);
  return matches.length === 1 && matches[0] === field.key;
}

async function highlightStructuralFieldTargets(roots, container, fieldInput) {
  const field = resolveFieldDefinition(fieldInput);
  const targets = collectSceneNodes(roots, 5000)
    .filter((node) => node.type !== "TEXT" && isFieldNodeName(node.name || "", field))
    .filter((node) => !isInsideProtectedNonCatalogField(node))
    .filter((node) => isNodeEffectivelyVisible(node))
    .filter((node, index, nodes) => !nodes.some((candidate, candidateIndex) =>
      candidateIndex !== index && isDescendantOrSelf(node, candidate)
    ));
  let changed = 0;
  for (const target of targets.slice(0, 600)) {
    const highlighted = await addHighlight(container, target, changed === 0, field);
    if (highlighted) changed += 1;
  }
  return changed;
}

function fieldKeyForComponentProperty(propertyName, property) {
  if (property && property.type !== "BOOLEAN") return "";
  const matches = fieldKeysForComponentProperty(propertyName);
  return matches.length === 1 ? matches[0] : "";
}

function fieldKeysForComponentProperty(propertyName) {
  return FIELD_CATALOG
    .filter((candidate) => matchesFieldComponentProperty(propertyName, candidate))
    .map((candidate) => candidate.key);
}

function fieldKeysForLayerName(name) {
  return FIELD_CATALOG
    .filter((candidate) => fieldContainerNameMatches(name, candidate))
    .map((candidate) => candidate.key);
}

function collectFieldControlCapabilities(roots) {
  const stack = roots.slice();
  const result = [];
  const seen = new Set();
  while (stack.length) {
    const node = stack.shift();
    if (!node) continue;
    if (node.type === "INSTANCE") {
      const componentProperties = getComponentPropertiesSafely(node);
      for (const propertyName of Object.keys(componentProperties || {})) {
        const property = componentProperties[propertyName];
        const fieldKey = fieldKeyForComponentProperty(propertyName, property);
        const signature = `${node.id}:${propertyName}`;
        if (fieldKey && !seen.has(signature)) {
          seen.add(signature);
          result.push({ node, propertyName, fieldKey, visible: property.value !== false });
        }
      }
    }
    if ("children" in node) {
      for (const child of node.children) stack.push(child);
    }
  }
  return result;
}

function matchesFieldComponentProperty(propertyName, fieldInput) {
  const field = resolveFieldDefinition(fieldInput);
  const definition = FIELD_COMPONENT_CONTROLS[field.key];
  if (!definition) return false;
  const normalized = normalizeComponentControlName(propertyName);
  return definition.properties.some((pattern) => pattern.test(normalized));
}

function matchesFieldLayerAlias(name, fieldInput) {
  const field = resolveFieldDefinition(fieldInput);
  const definition = FIELD_COMPONENT_CONTROLS[field.key];
  if (!definition) return false;
  const normalized = normalizeComponentControlName(name);
  return definition.layers.some((pattern) => pattern.test(normalized));
}

function normalizeComponentControlName(value) {
  return String(value || "")
    .replace(/#.*$/, "")
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .toLowerCase()
    .replace(/inatall/g, "install")
    .replace(/recyle/g, "recycle")
    .replace(/garantee/g, "guarantee")
    .replace(/&/g, " and ")
    .replace(/[_/–—-]+/g, " ")
    .replace(/[()[\]{}:：,.·'"‘’]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function fieldTargetScore(node, fieldInput) {
  const field = resolveFieldDefinition(fieldInput);
  const context = nodeFieldContext(node);
  const nodeName = normalizeComponentControlName(node && node.name || "");
  const text = String(node.characters || "").trim().toLowerCase();
  if (/change highlight|change note|generated design|design title/.test(context)) return -100;
  if (isInsideProtectedNonCatalogField(node)) return -95;
  const ownerFieldKey = nearestSemanticFieldOwnerKey(node);
  if (ownerFieldKey && ownerFieldKey !== field.key) return -90;
  if (!ownerFieldKey && textMatchesConflictingOperationalField(text, field)) return -80;
  if (field.key === "masterPromotion" && /single[\s_-]*promotion|individual[\s_-]*promotion|单促|lightning/.test(nodeName)) return -50;
  if (field.key !== "price" && /(?:^|[\s_-])price(?:$|[\s_-])|unit[\s_-]*price|价格|单价/.test(nodeName) && !fieldNameMatchesDirectly(nodeName, field)) return -30;

  let score = 0;
  const matchesTargetName = fieldNameMatchesDirectly(nodeName, field) || ownerFieldKey === field.key;
  if (matchesTargetName) score += 22;
  if (!matchesTargetName && contextMatchesOtherField(nodeName, field)) return -40;
  if (hasExplicitFieldNumber(nodeName, field.slotNumber)) score += 4;
  if (field.text) {
    field.text.lastIndex = 0;
    if (field.text.test(text)) score += 12;
  }
  return score;
}

function nearestSemanticFieldOwnerKey(node) {
  const owner = nearestSemanticFieldOwner(node);
  return owner ? owner.fieldKey : "";
}

function nearestSemanticFieldOwner(node) {
  let current = node && node.parent;
  let depth = 0;
  let nearestOwner = null;
  while (current && depth < 8) {
    const rawName = String(current.name || "");
    if (/^(?:zh|en|de|fr|nl|it)\s*·/i.test(rawName) || current.getPluginData && current.getPluginData("joybuy-card-copilot")) break;
    const normalized = normalizeComponentControlName(rawName);
    if (protectedNonCatalogFieldContainerMatches(normalized)) {
      return { fieldKey: "__protected_non_catalog__", node: current };
    }
    if (!nearestOwner && !isGenericTextWrapperName(normalized)) {
      const matches = FIELD_CATALOG.filter((candidate) => fieldContainerNameMatches(normalized, candidate));
      if (matches.length === 1) nearestOwner = { fieldKey: matches[0].key, node: current };
    }
    current = current.parent;
    depth += 1;
  }
  return nearestOwner;
}

function protectedNonCatalogFieldContainerMatches(name) {
  const normalized = normalizeComponentControlName(name);
  return PROTECTED_NON_CATALOG_FIELD_CONTAINERS.some((pattern) => pattern.test(normalized));
}

function isInsideProtectedNonCatalogField(node) {
  let current = node;
  let depth = 0;
  while (current && depth < 10) {
    const rawName = String(current.name || "");
    if (protectedNonCatalogFieldContainerMatches(rawName)) return true;
    if (/^(?:zh|en|de|fr|nl|it)\s*·/i.test(rawName) || current.getPluginData && current.getPluginData("joybuy-card-copilot")) break;
    current = current.parent;
    depth += 1;
  }
  return false;
}

function fieldContainerNameMatches(normalizedName, fieldInput) {
  const field = resolveFieldDefinition(fieldInput);
  const normalized = normalizeComponentControlName(normalizedName);
  const normalizedEnglish = normalizeComponentControlName(field.english);
  const normalizedLabel = normalizeComponentControlName(field.label.replace(/（可选）|\(optional\)/gi, ""));
  if (normalized === normalizedEnglish || normalized === normalizedLabel) return true;
  if (hasExplicitFieldNumber(normalized, field.slotNumber) && fieldNameMatchesDirectly(normalized, field)) return true;
  return matchesFieldLayerAlias(normalized, field);
}

function fieldNameMatchesDirectly(normalizedName, fieldInput) {
  const field = resolveFieldDefinition(fieldInput);
  const normalized = normalizeComponentControlName(normalizedName);
  field.name.lastIndex = 0;
  return field.name.test(normalized) || matchesFieldLayerAlias(normalized, field);
}

function isGenericTextWrapperName(name) {
  return /^product title$|^(?:text|label|content|container|wrapper|frame)(?: \d+)?$/.test(String(name || ""));
}

function textMatchesConflictingOperationalField(text, targetField) {
  const operationalKeys = new Set([
    "singlePromotion",
    "masterPromotion",
    "bottleDeposit",
    "stock",
    "fulfillment",
    "officialTag",
    "service",
    "performance"
  ]);
  if (!operationalKeys.has(targetField.key)) return false;
  return FIELD_CATALOG.some((candidate) => {
    if (candidate.key === targetField.key || !operationalKeys.has(candidate.key) || !candidate.text) return false;
    candidate.text.lastIndex = 0;
    return candidate.text.test(text);
  });
}

function contextMatchesOtherField(context, targetField) {
  return FIELD_CATALOG.some((candidate) => {
    if (candidate.key === targetField.key) return false;
    candidate.name.lastIndex = 0;
    return candidate.name.test(context) || matchesFieldLayerAlias(context, candidate);
  });
}

function nodeFieldContext(node) {
  const names = [node && node.name || ""];
  let parent = node && node.parent;
  let depth = 0;
  while (parent && depth < 3) {
    if (/^(?:zh|en|de|fr|nl|it)\s*·/i.test(String(parent.name || "")) || parent.getPluginData && parent.getPluginData("joybuy-card-copilot")) break;
    names.push(parent.name || "");
    parent = parent.parent;
    depth += 1;
  }
  return names.join(" ").toLowerCase();
}

function hasExplicitFieldNumber(value, slotNumber) {
  return new RegExp(`(?:^|[^0-9])${slotNumber}(?:[^0-9]|$)`).test(String(value || ""));
}

function promotionScore(node) {
  return fieldTargetScore(node, resolveFieldDefinition("masterPromotion"));
}

function collectTextNodes(roots, limit) {
  const result = [];
  const stack = roots.slice();
  while (stack.length && result.length < limit) {
    const node = stack.shift();
    if (!node) continue;
    if (node.type === "TEXT") result.push(node);
    if ("children" in node) {
      for (const child of node.children) stack.push(child);
    }
  }
  return result;
}

function isNodeEffectivelyVisible(node) {
  return Boolean(getNodeVisibleBounds(node));
}

function getNodeVisibleBounds(node) {
  if (!node) return null;
  let bounds = normalizeBounds(node.absoluteBoundingBox);
  if (!bounds) return null;
  let current = node;
  let effectiveOpacity = 1;
  while (current) {
    if ("visible" in current && current.visible === false) return null;
    if ("opacity" in current && Number.isFinite(Number(current.opacity))) {
      effectiveOpacity *= Math.max(0, Math.min(1, Number(current.opacity)));
      if (effectiveOpacity <= 0.001) return null;
    }
    if (current !== node && current.clipsContent === true) {
      const clipBounds = normalizeBounds(current.absoluteBoundingBox);
      if (!clipBounds) return null;
      bounds = intersectBounds(bounds, clipBounds);
      if (!bounds) return null;
    }
    if (current.type === "PAGE") break;
    current = current.parent;
  }
  return bounds;
}

function normalizeBounds(bounds) {
  if (!bounds) return null;
  const x = Number(bounds.x);
  const y = Number(bounds.y);
  const width = Number(bounds.width);
  const height = Number(bounds.height);
  if (![x, y, width, height].every(Number.isFinite) || width <= 0 || height <= 0) return null;
  return { x, y, width, height };
}

function intersectBounds(left, right) {
  const x = Math.max(left.x, right.x);
  const y = Math.max(left.y, right.y);
  const rightEdge = Math.min(left.x + left.width, right.x + right.width);
  const bottomEdge = Math.min(left.y + left.height, right.y + right.height);
  if (rightEdge <= x || bottomEdge <= y) return null;
  return { x, y, width: rightEdge - x, height: bottomEdge - y };
}

async function loadTextFonts(textNode) {
  if (!textNode.characters.length) {
    if (textNode.fontName !== figma.mixed) await figma.loadFontAsync(textNode.fontName);
    return;
  }
  const fonts = textNode.getRangeAllFontNames(0, textNode.characters.length);
  const unique = [];
  for (const font of fonts) {
    if (!unique.some((item) => item.family === font.family && item.style === font.style)) unique.push(font);
  }
  await Promise.all(unique.map((font) => figma.loadFontAsync(font)));
}

function applyOverflow(textNode, strategy) {
  try {
    if (strategy === "wrap") {
      textNode.textAutoResize = "HEIGHT";
      if ("textTruncation" in textNode) textNode.textTruncation = "DISABLED";
      if ("maxLines" in textNode) textNode.maxLines = null;
    } else {
      if ("textTruncation" in textNode) textNode.textTruncation = "ENDING";
      if ("maxLines" in textNode) textNode.maxLines = 1;
    }
  } catch (error) {
    // Preserve the source component's text sizing when the property is read-only.
  }
}

function chooseOverflow(mode, suggested, copy, availableWidth, fontSize) {
  if (mode === "wrap" || mode === "ellipsis") return mode;
  const text = String(copy || "");
  const width = Number(availableWidth) || 157;
  const size = Number(fontSize) || 11;
  const estimatedWidth = weightedTextLength(text) * size * 0.56;
  if (estimatedWidth > width * 1.12) return "wrap";
  return suggested === "wrap" && estimatedWidth > width * 0.88 ? "wrap" : "ellipsis";
}

function weightedTextLength(text) {
  let units = 0;
  for (const character of String(text || "")) {
    units += /[\u0000-\u00ff]/.test(character) ? 0.58 : 1;
  }
  return units;
}

function numericFontSize(textNode) {
  return typeof textNode.fontSize === "number" ? textNode.fontSize : 11;
}

function candidateWidthFallback(nodes, fieldInput) {
  const field = resolveFieldDefinition(fieldInput);
  const candidate = collectTextNodes(nodes, 300)
    .map((node) => ({ node, score: fieldTargetScore(node, field) }))
    .filter((item) => isNodeEffectivelyVisible(item.node))
    .sort((a, b) => b.score - a.score)[0];
  return candidate && candidate.node.width ? candidate.node.width : 157;
}

async function addHighlight(container, target, withLabel, fieldInput) {
  const field = resolveFieldDefinition(fieldInput || "masterPromotion");
  const targetBounds = getNodeVisibleBounds(target);
  const containerBounds = normalizeBounds(container && container.absoluteBoundingBox);
  if (!targetBounds || !containerBounds) return false;
  const outline = figma.createRectangle();
  outline.name = `Change highlight · Field ${field.slotNumber}`;
  outline.x = targetBounds.x - containerBounds.x - 5;
  outline.y = targetBounds.y - containerBounds.y - 4;
  outline.resize(Math.max(24, targetBounds.width + 10), Math.max(20, targetBounds.height + 8));
  outline.fills = [];
  outline.strokes = [solid("F0B429")];
  outline.strokeWeight = 2;
  outline.cornerRadius = 4;
  outline.dashPattern = [5, 3];
  container.appendChild(outline);

  if (withLabel) {
    const label = await makeText(`${field.slotNumber} · ${field.english.toUpperCase()} · CHANGED`, 9, "Bold", "553A00");
    label.name = "Change note";
    label.x = outline.x;
    label.y = Math.max(2, outline.y - 20);
    container.appendChild(label);
    const backing = figma.createRectangle();
    backing.name = "Change note background";
    backing.x = label.x - 5;
    backing.y = label.y - 3;
    backing.resize(label.width + 10, label.height + 6);
    backing.cornerRadius = 4;
    backing.fills = [solid("FFE08A")];
    container.insertChild(container.children.length - 1, backing);
  }
  return true;
}

async function addMissingFieldNotice(frame, sceneX, fieldInput) {
  const field = resolveFieldDefinition(fieldInput);
  const note = await makeText(`${field.slotNumber} · ${field.english.toUpperCase()} · FIELD NOT FOUND`, 9, "Bold", "9A3412");
  note.name = `Field warning · ${field.slotNumber}`;
  note.x = sceneX;
  note.y = 38;
  frame.appendChild(note);
}

async function drawDemoScreen(screen, locale, analysis, overflowMode) {
  const time = await makeText("9:41", 10, "Bold", "202126");
  time.name = "Status bar time";
  time.x = 16;
  time.y = 10;
  screen.appendChild(time);
  const status = await makeText("●  ◒  ▰", 8, "Regular", "34353B");
  status.name = "Status bar indicators";
  status.x = 307;
  status.y = 11;
  screen.appendChild(status);

  const back = await makeText("‹", 26, "Regular", "202126");
  back.name = "Back";
  back.x = 15;
  back.y = 29;
  screen.appendChild(back);
  const pageTitle = await makeText(locale === "zh" ? "搜索结果" : "Search results", 15, "Bold", "202126");
  pageTitle.name = "Page title";
  pageTitle.x = 46;
  pageTitle.y = 36;
  screen.appendChild(pageTitle);

  const search = figma.createRectangle();
  search.x = 16;
  search.y = 62;
  search.resize(343, 40);
  search.cornerRadius = 8;
  search.fills = [solid("FFFFFF")];
  search.strokes = [solid("B7B8BF")];
  screen.appendChild(search);
  const searchText = await makeText(locale === "zh" ? "空气炸锅" : "Air fryer", 13, "Regular", "292A30");
  searchText.x = 30;
  searchText.y = 74;
  screen.appendChild(searchText);
  const searchIcon = await makeText("⌕", 18, "Regular", "555761");
  searchIcon.name = "Search icon";
  searchIcon.x = 331;
  searchIcon.y = 70;
  screen.appendChild(searchIcon);

  const chips = locale === "zh" ? ["筛选", "排序", "品牌", "品类"] : ["Filter", "Sort", "Brand", "Category"];
  for (let index = 0; index < chips.length; index += 1) {
    const chip = figma.createRectangle();
    chip.x = 16 + index * 86;
    chip.y = 114;
    chip.resize(78, 32);
    chip.cornerRadius = 6;
    chip.fills = [solid("F4F4F6")];
    screen.appendChild(chip);
    const chipText = await makeText(chips[index], 10, "Regular", "41424A");
    chipText.x = chip.x + 10;
    chipText.y = chip.y + 9;
    screen.appendChild(chipText);
  }

  const resultLabel = await makeText(locale === "zh" ? "为你找到 1,000+ 件商品" : "1,000+ products found", 10, "Bold", "34353B");
  resultLabel.name = "Result summary";
  resultLabel.x = 16;
  resultLabel.y = 157;
  screen.appendChild(resultLabel);
  const viewLabel = await makeText(locale === "zh" ? "双列" : "Grid", 9, "Regular", "74767F");
  viewLabel.name = "View mode";
  viewLabel.x = 328;
  viewLabel.y = 158;
  screen.appendChild(viewLabel);

  const promo = analysis.translations[locale] || analysis.translations.zh;
  const field = resolveFieldDefinition(analysis.placement.fieldKey || analysis.placement.slotNumber);
  let changed = 0;
  changed += await drawProductCard(screen, 16, 180, locale, promo, 0, overflowMode, analysis.overflow[locale], field, analysis.targetVisible !== false);
  changed += await drawProductCard(screen, 194, 180, locale, promo, 1, overflowMode, analysis.overflow[locale], field, analysis.targetVisible !== false);

  const bottomBar = figma.createRectangle();
  bottomBar.name = "Bottom navigation";
  bottomBar.x = 0;
  bottomBar.y = 738;
  bottomBar.resize(375, 42);
  bottomBar.fills = [solid("FFFFFF")];
  bottomBar.strokes = [solid("ECEDEF")];
  screen.appendChild(bottomBar);
  const navText = await makeText(locale === "zh" ? "首页        分类        购物车        我的" : "Home       Categories       Cart       Account", 9, "Regular", "70727A");
  navText.name = "Bottom navigation labels";
  navText.x = 25;
  navText.y = 753;
  screen.appendChild(navText);
  return changed;
}

async function drawProductCard(parent, x, y, locale, promo, variant, overflowMode, suggestedOverflow, fieldInput, targetVisible) {
  const field = resolveFieldDefinition(fieldInput);
  const card = figma.createFrame();
  card.name = "Universal 2-column product card";
  card.x = x;
  card.y = y;
  card.resize(165, 526);
  card.fills = [solid("FFFFFF")];
  card.cornerRadius = 10;
  card.clipsContent = false;
  parent.appendChild(card);

  const image = figma.createRectangle();
  image.name = "Product picture";
  image.resize(165, 180);
  image.cornerRadius = 8;
  const productFills = demoProductFills(variant);
  image.fills = productFills;
  card.appendChild(image);

  if (!productFills.some((fill) => fill.type === "IMAGE")) {
    const product = figma.createRectangle();
    product.name = "Product silhouette";
    product.resize(variant ? 62 : 48, variant ? 112 : 126);
    product.x = variant ? 52 : 58;
    product.y = variant ? 34 : 28;
    product.cornerRadius = variant ? 8 : 16;
    product.fills = [solid(variant ? "C9252D" : "D9959E")];
    card.appendChild(product);
  }

  const brand = await makeText("Apple", 11, "Bold", "222328");
  brand.name = "Brand Name";
  brand.x = 4;
  brand.y = 192;
  card.appendChild(brand);
  const figmaTitles = [
    "Seeded Sourdough Bread\nSystem",
    "French Door Refrigerator Freeze Ice & Water",
    "iPhone 16 Pro Max 256GB Black Titanium"
  ];
  const titleCopy = figmaTitles[variant ? 1 : 0];
  const title = await makeText(titleCopy, 11, "Regular", "292A30");
  title.name = "Product title";
  title.x = 4;
  title.y = 211;
  title.resize(157, 34);
  title.textAutoResize = "HEIGHT";
  card.appendChild(title);

  const ratingValue = await makeText("4.5", 9, "Regular", "555761");
  ratingValue.name = "Rating";
  ratingValue.x = 4;
  ratingValue.y = 254;
  card.appendChild(ratingValue);
  const ratingSold = await makeText("100k+ sold", 9, "Regular", "555761");
  ratingSold.name = "Sales Volume";
  ratingSold.x = 24;
  ratingSold.y = 254;
  card.appendChild(ratingSold);
  const lightning = await makeText("Lightning offers", 10, "Bold", "E1251B");
  lightning.name = "Single Promotion";
  lightning.x = 4;
  lightning.y = 276;
  card.appendChild(lightning);
  const price = await makeText("£350.00", 16, "Bold", "E1251B");
  price.name = "Price";
  price.x = 4;
  price.y = 300;
  card.appendChild(price);
  const rrp = await makeText("RRP: £500.00", 9, "Regular", "6C6E77");
  rrp.x = 4;
  rrp.y = 326;
  card.appendChild(rrp);
  const discount = await makeText("Save 18% on RRP", 9, "Regular", "494B53");
  discount.x = 4;
  discount.y = 344;
  card.appendChild(discount);

  const promotion = await makeText("Buy 1 get 1 free", 11, "Bold", "E1251B");
  promotion.name = "11 · Master Promotion · 总促";
  promotion.x = 4;
  promotion.y = 370;
  promotion.resize(157, 17);
  card.appendChild(promotion);
  const verticalOffset = 0;
  const delivery = await makeText("Get it by today", 9, "Regular", "555761");
  delivery.name = "Fulfillment Time";
  delivery.x = 4;
  delivery.y = 423 + verticalOffset;
  card.appendChild(delivery);
  const seller = await makeText("Sold by Joybuy", 9, "Bold", "404149");
  seller.name = "Official Tag";
  seller.x = 4;
  seller.y = 445 + verticalOffset;
  card.appendChild(seller);
  const service = await makeText("Install & Recyle", 9, "Regular", "555761");
  service.name = "17 · Service · 服务";
  service.x = 4;
  service.y = 463;
  card.appendChild(service);

  const button = figma.createEllipse();
  button.name = "Add button";
  button.resize(32, 32);
  button.x = 125;
  button.y = 476 + verticalOffset;
  button.fills = [solid("F4F4F6")];
  card.appendChild(button);
  const plus = await makeText("+", 20, "Regular", "202126");
  plus.name = "Add button icon";
  plus.x = 135;
  plus.y = 479 + verticalOffset;
  card.appendChild(plus);
  if (targetVisible === false) {
    setFieldVisibility([card], field, false);
    return 0;
  }
  return updateFieldTargets(
    [card],
    parent,
    field,
    locale,
    promo,
    chooseOverflow(overflowMode, suggestedOverflow, promo, 157, 11)
  );
}

/**
 * @param {number} variant
 * @returns {Paint[]}
 */
function demoProductFills(variant) {
  const fallback = solid(variant ? "F1F1F3" : "F5F2EE");
  try {
    const index = variant ? 1 : 0;
    if (!demoImageHashes[index]) {
      const bytes = figma.base64Decode(DEMO_PRODUCT_IMAGES[index]);
      demoImageHashes[index] = figma.createImage(bytes).hash;
    }
    const imagePaint = /** @type {ImagePaint} */ ({
        type: "IMAGE",
        scaleMode: "FIT",
        imageHash: demoImageHashes[index]
      });
    return [fallback, imagePaint];
  } catch (error) {
    return [fallback];
  }
}

async function makeText(characters, size, style, color) {
  let font = { family: "Inter", style };
  try {
    await figma.loadFontAsync(font);
  } catch (error) {
    font = { family: "Inter", style: "Regular" };
    await figma.loadFontAsync(font);
  }
  const text = figma.createText();
  text.fontName = font;
  text.fontSize = size;
  text.characters = String(characters || "");
  text.fills = [solid(color)];
  return text;
}

function selectionBounds(nodes) {
  const boxes = nodes.map((node) => node.absoluteBoundingBox).filter(Boolean);
  if (!boxes.length) return null;
  const minX = Math.min(...boxes.map((box) => box.x));
  const minY = Math.min(...boxes.map((box) => box.y));
  const maxX = Math.max(...boxes.map((box) => box.x + box.width));
  const maxY = Math.max(...boxes.map((box) => box.y + box.height));
  return { x: minX, y: minY, width: maxX - minX, height: maxY - minY };
}

/**
 * @param {string} hex
 * @param {number=} opacity
 * @returns {SolidPaint}
 */
function solid(hex, opacity) {
  const value = hex.replace("#", "");
  return {
    type: "SOLID",
    color: {
      r: parseInt(value.slice(0, 2), 16) / 255,
      g: parseInt(value.slice(2, 4), 16) / 255,
      b: parseInt(value.slice(4, 6), 16) / 255
    },
    opacity: opacity === undefined ? 1 : opacity
  };
}
